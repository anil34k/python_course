def main():
    # Question: Find the second smallest element.
    numbers = [4, -2, 7, 0, 9, 3]
    smallest = float('inf')
    second = float('inf')
    for number in numbers:
        if number < smallest:
            second = smallest
            smallest = number
        elif number < second and number != smallest:
            second = number
    print("Second smallest = " + str(second))


if __name__ == "__main__":
    main()

"""
Explanation:
The variables `smallest`, and `numbers` hold the values that the logic checks, counts, or transforms.
The enhanced `for` loop visits every element in the array one by one.
The if/else checks test the important cases in order: `number < smallest`, `number < second && number != smallest`.
The print statement shows each value as soon as that value is calculated inside the loop.
"""
