def main():
    # Question 47: : Count how many pairs of elements have a sum equal to a given number k.
    numbers = [1, 2, 3, 4, 5]
    k = 6
    for i in range(0, len(numbers)):
        for j in range(i + 1, len(numbers)):
            if numbers[i] + numbers[j] == k:
                print(str(numbers[i]) + ", " + str(numbers[j]))


if __name__ == "__main__":
    main()

"""
Explanation:
The variables `k`, and `numbers` hold the values that the logic checks, counts, or transforms.
The `for` loop starts with `int i = 0`, keeps running while `i < numbers.length` is true, and updates using `i++`.
The condition `numbers[i] + numbers[j] == k` decides whether the current value matches the requirement.
The print statement shows each value as soon as that value is calculated inside the loop.
"""
