def main():
    # Question 49: : Print the frequency of each distinct element.
    numbers = [4, 7, 4, 2, 7, 9, 2]
    visited = [False] * (len(numbers))

    for i in range(0, len(numbers)):
        if visited[i]:
            continue

        count = 1
        for j in range(i + 1, len(numbers)):
            if numbers[i] == numbers[j]:
                count += 1
                visited[j] = True

        print(str(numbers[i]) + " appears " + str(count) + " times")


if __name__ == "__main__":
    main()

"""
Explanation:
The variables `numbers`, and `visited` hold the values that the logic checks, counts, or transforms.
The `for` loop starts with `int i = 0`, keeps running while `i < numbers.length` is true, and updates using `i++`.
The if/else checks test the important cases in order: `visited[i]`, `numbers[i] == numbers[j]`.
The print statement shows each value as soon as that value is calculated inside the loop.
"""
