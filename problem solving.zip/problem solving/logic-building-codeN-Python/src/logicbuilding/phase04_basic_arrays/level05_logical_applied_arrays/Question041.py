def main():
    # Question 41: : Check if the array is sorted in ascending order.
    numbers = [1, 2, 3, 4]
    sorted = True
    for i in range(1, len(numbers)):
        if numbers[i] < numbers[i - 1]:
            sorted = False
    print("Ascending" if sorted else "Not ascending")


if __name__ == "__main__":
    main()

"""
Explanation:
The variables `sorted`, and `numbers` hold the values that the logic checks, counts, or transforms.
The `for` loop starts with `int i = 1`, keeps running while `i < numbers.length` is true, and updates using `i++`.
The condition `numbers[i] < numbers[i - 1]` decides whether the current value matches the requirement.
The print statement shows each value as soon as that value is calculated inside the loop.
"""
