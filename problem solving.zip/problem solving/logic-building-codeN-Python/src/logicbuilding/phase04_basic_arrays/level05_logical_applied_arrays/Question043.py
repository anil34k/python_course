def main():
    # Question: Find the second largest element.
    numbers = [4, -2, 7, 0, 9, 3]
    largest = float('-inf')
    second = float('-inf')
    for number in numbers:
        if number > largest:
            second = largest
            largest = number
        elif number > second and number != largest:
            second = number
    print("Second largest = " + str(second))


if __name__ == "__main__":
    main()

"""
Explanation:
The variables `largest`, and `numbers` hold the values that the logic checks, counts, or transforms.
The enhanced `for` loop visits every element in the array one by one.
The if/else checks test the important cases in order: `number > largest`, `number > second && number != largest`.
The print statement shows each value as soon as that value is calculated inside the loop.
"""
