def main():
    # Question 50: : Print all unique elements (those that occur exactly once).
    numbers = [4, -2, 7, 0, 7, 3]
    for i in range(0, len(numbers)):
        count = 0
        for value in numbers:
            if value == numbers[i]:
                count += 1
        if count == 1:
            print(numbers[i])


if __name__ == "__main__":
    main()

"""
Explanation:
The value stored in `numbers` is the input that the conditions or loops work on.
The enhanced `for` loop visits every element in the array one by one.
The variable `count` starts at 0 and increases only when the current item satisfies the question's condition.
The if/else checks test the important cases in order: `value == numbers[i]`, `count == 1`.
The print statement shows each value as soon as that value is calculated inside the loop.
"""
