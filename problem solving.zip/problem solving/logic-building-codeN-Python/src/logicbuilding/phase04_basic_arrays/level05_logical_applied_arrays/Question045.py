def main():
    # Question 45: : Find the difference between the largest and smallest element.
    numbers = [4, -2, 7, 0, 9, 3]
    largest = numbers[0]
    smallest = numbers[0]

    for number in numbers:
        if number > largest:
            largest = number
        if number < smallest:
            smallest = number

    print("Difference = " + str((largest - smallest)))


if __name__ == "__main__":
    main()

"""
Explanation:
The variables `largest`, `smallest`, and `numbers` hold the values that the logic checks, counts, or transforms.
The enhanced `for` loop visits every element in the array one by one.
The if/else checks test the important cases in order: `number > largest`, `number < smallest`.
The print statement shows each value as soon as that value is calculated inside the loop.
"""
