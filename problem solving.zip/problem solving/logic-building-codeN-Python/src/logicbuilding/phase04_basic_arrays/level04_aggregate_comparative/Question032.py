def main():
    # Question 32: : Compare two arrays - check if they contain the same elements (ignore order).
    first = [1, 2, 3]
    second = [3, 2, 1]
    same = len(first) == len(second)
    used = [False] * (len(second))
    for i in range(0, len(first) and same):
        found = False
        for j in range(0, len(second)):
            if not used[j] and first[i] == second[j]:
                used[j] = True
                found = True
                break
        if not found:
            same = False
    print("Same elements" if same else "Different elements")


if __name__ == "__main__":
    main()

"""
Explanation:
The variables `same`, `first`, `second`, and `used` hold the values that the logic checks, counts, or transforms.
The `for` loop starts with `int i = 0`, keeps running while `i < first.length && same` is true, and updates using `i++`.
The boolean `found` starts as false and becomes true as soon as the searched value is seen.
The if/else checks test the important cases in order: `!used[j] && first[i] == second[j]`, `!found`.
The print statement shows each value as soon as that value is calculated inside the loop.
"""
