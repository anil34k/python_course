def main():
    # Question 39: : Create a frequency array of numbers (count occurrence of each number).
    numbers = [4, -2, 7, 0, 7, 3]
    visited = [False] * (len(numbers))
    for i in range(0, len(numbers)):
        if visited[i]:
            continue
        count = 1
        for j in range(i + 1, len(numbers)):
            if numbers[i] == numbers[j]:
                visited[j] = True
                count += 1
print(str(numbers[i]) + " -> " + str(count))


if __name__ == "__main__":
    main()

"""
Explanation:
The variables `numbers`, and `visited` hold the values that the logic checks, counts, or transforms.
The `for` loop starts with `int i = 0`, keeps running while `i < numbers.length` is true, and updates using `i++`.
The condition `numbers[i] == numbers[j]` decides whether the current value matches the requirement.
The print statement shows each value as soon as that value is calculated inside the loop.
"""
