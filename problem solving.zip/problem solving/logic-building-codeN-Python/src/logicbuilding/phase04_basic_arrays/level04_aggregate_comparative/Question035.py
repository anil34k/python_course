def main():
    # Question 35: : Find elements that are in one array but not in the other.
    first = [1, 2, 3, 4]
    second = [3, 4, 5]
    for a in first:
        found = False
        for b in second:
            if a == b:
                found = True
        if not found:
            print(a)


if __name__ == "__main__":
    main()

"""
Explanation:
The variables `first`, and `second` hold the values that the logic checks, counts, or transforms.
The `for` loop starts with `int a : first) { boolean found = false`, keeps running while `for (int b : second) if (a == b) found = true` is true, and updates using `if (!found`.
The boolean `found` starts as false and becomes true as soon as the searched value is seen.
The if/else checks test the important cases in order: `a == b`, `!found`.
The print statement shows each value as soon as that value is calculated inside the loop.
"""
