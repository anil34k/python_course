def main():
    # Question 34: : Find the common elements between two arrays.
    first = [1, 2, 3, 4]
    second = [3, 4, 5]
    for a in first:
        for b in second:
            if a == b:
                print(a)


if __name__ == "__main__":
    main()

"""
Explanation:
The variables `first`, and `second` hold the values that the logic checks, counts, or transforms.
The loop repeats the same check or calculation for every required value.
The condition `a == b` decides whether the current value matches the requirement.
The print statement shows each value as soon as that value is calculated inside the loop.
"""
