def printArray(values):
    for value in values:
        print(str(value) + " ", end="")
    print()

def main():
    # Question 38: : Find element-wise product of two arrays.
    a = [1, 2, 3]
    b = [4, 5, 6]
    result = [0] * (len(a))
    for i in range(0, len(a)):
        result[i] = a[i] * b[i]
    printArray(result)


if __name__ == "__main__":
    main()

"""
Explanation:
The variables `a`, and `b` hold the values that the logic checks, counts, or transforms.
The helper calculates the required result and returns it to the print statement.
The `for` loop starts with `int i = 0`, keeps running while `i < a.length` is true, and updates using `i++`.
"""
