def printArray(values):
    for value in values:
        print(str(value) + " ", end="")
    print()

def main():
    # Question 33: : Merge two arrays into a third array.
    first = [1, 2, 3]
    second = [4, 5]
    merged = [0] * (len(first) + len(second))
    for i in range(0, len(first)):
        merged[i] = first[i]
    for i in range(0, len(second)):
        merged[len(first) + i] = second[i]
    printArray(merged)


if __name__ == "__main__":
    main()

"""
Explanation:
The variables `first`, `second`, and `merged` hold the values that the logic checks, counts, or transforms.
The helper calculates the required result and returns it to the print statement.
The `for` loop starts with `int i = 0`, keeps running while `i < first.length` is true, and updates using `i++`.
"""
