def main():
    # Question 31: : Compare two arrays - check if they are equal (same elements & order).
    first = [1, 2, 3]
    second = [1, 2, 3]
    equal = len(first) == len(second)
    for i in range(0, len(first) and equal):
        if first[i] != second[i]:
            equal = False
    print("Equal" if equal else "Not equal")


if __name__ == "__main__":
    main()

"""
Explanation:
The variables `equal`, `first`, and `second` hold the values that the logic checks, counts, or transforms.
The `for` loop starts with `int i = 0`, keeps running while `i < first.length && equal` is true, and updates using `i++`.
The condition `first[i] != second[i]` decides whether the current value matches the requirement.
The print statement shows each value as soon as that value is calculated inside the loop.
"""
