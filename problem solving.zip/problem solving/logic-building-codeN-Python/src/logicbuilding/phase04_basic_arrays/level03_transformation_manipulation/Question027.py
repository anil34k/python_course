def printArray(values):
    for value in values:
        print(str(value) + " ", end="")
    print()

def main():
    # Question 27: : Rotate an array by one position to the left.
    numbers = [4, -2, 7, 0, 7, 3]
    first = numbers[0]
    for i in range(0, len(numbers) - 1):
        numbers[i] = numbers[i + 1]
    numbers[len(numbers) - 1] = first
    printArray(numbers)


if __name__ == "__main__":
    main()

"""
Explanation:
The variables `first`, and `numbers` hold the values that the logic checks, counts, or transforms.
The helper calculates the required result and returns it to the print statement.
The `for` loop starts with `int i = 0`, keeps running while `i < numbers.length - 1` is true, and updates using `i++`.
"""
