def printArray(values):
    for value in values:
        print(str(value) + " ", end="")
    print()

def main():
    # Question 25: : Swap the first and last elements of the array.
    numbers = [4, -2, 7, 0, 7, 3]
    temp = numbers[0]
    numbers[0] = numbers[len(numbers) - 1]
    numbers[len(numbers) - 1] = temp
    printArray(numbers)


if __name__ == "__main__":
    main()

"""
Explanation:
The variables `temp`, and `numbers` hold the values that the logic checks, counts, or transforms.
The helper calculates the required result and returns it to the print statement.
"""
