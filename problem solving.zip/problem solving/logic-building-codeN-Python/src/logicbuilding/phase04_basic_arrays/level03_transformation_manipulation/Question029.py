def printArray(values):
    for value in values:
        print(str(value) + " ", end="")
    print()

def main():
    # Question 29: : Swap alternate elements (1st <-> 2nd, 3rd <-> 4th, etc.).
    numbers = [4, -2, 7, 0, 7, 3]
    i = 0
    while i + 1 < len(numbers):
        temp = numbers[i]
        numbers[i] = numbers[i + 1]
        numbers[i + 1] = temp
        i += 2
printArray(numbers)


if __name__ == "__main__":
    main()

"""
Explanation:
The variables `temp`, and `numbers` hold the values that the logic checks, counts, or transforms.
The helper calculates the required result and returns it to the print statement.
The `for` loop starts with `int i = 0`, keeps running while `i + 1 < numbers.length` is true, and updates using `i += 2`.
"""
