def printArray(values):
    for value in values:
        print(str(value) + " ", end="")
    print()

def main():
    # Question 26: : Reverse an array (without using built-in reverse).
    numbers = [4, -2, 7, 0, 7, 3]
    left = 0
    right = len(numbers) - 1
    while left < right:
        temp = numbers[left]
        numbers[left] = numbers[right]
        numbers[right] = temp
        left += 1
        right -= 1
printArray(numbers)


if __name__ == "__main__":
    main()

"""
Explanation:
The variables `left`, `temp`, and `numbers` hold the values that the logic checks, counts, or transforms.
The helper builds the answer from the last digit or last character toward the first one.
The `while` or `do-while` loop keeps repeating until the changing value reaches the stopping condition.
"""
