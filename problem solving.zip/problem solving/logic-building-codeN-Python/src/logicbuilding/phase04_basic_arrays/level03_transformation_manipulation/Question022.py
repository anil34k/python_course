def main():
    # Question 22: : Create a new array containing only even elements.
    numbers = [4, -2, 7, 0, 7, 3]
    for number in numbers:
        if number % 2 == 0:
            print(number)


if __name__ == "__main__":
    main()

"""
Explanation:
The value stored in `numbers` is the input that the conditions or loops work on.
The enhanced `for` loop visits every element in the array one by one.
The condition `number % 2 == 0` decides whether the current value matches the requirement.
The print statement shows each value as soon as that value is calculated inside the loop.
"""
