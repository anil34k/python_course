def printArray(values):
    for value in values:
        print(str(value) + " ", end="")
    print()

def main():
    # Question 30: : Copy one array to another manually.
    numbers = [4, -2, 7, 0, 7, 3]
    copy = [0] * (len(numbers))
    for i in range(0, len(numbers)):
        copy[i] = numbers[i]
    printArray(copy)


if __name__ == "__main__":
    main()

"""
Explanation:
The variables `numbers`, and `copy` hold the values that the logic checks, counts, or transforms.
The helper calculates the required result and returns it to the print statement.
The `for` loop starts with `int i = 0`, keeps running while `i < numbers.length` is true, and updates using `i++`.
"""
