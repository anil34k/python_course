def printArray(values):
    for value in values:
        print(str(value) + " ", end="")
    print()

def main():
    # Question 21: : Create a new array containing squares of all numbers.
    numbers = [4, -2, 7, 0, 7, 3]
    squares = [0] * (len(numbers))
    for i in range(0, len(numbers)):
        squares[i] = numbers[i] * numbers[i]
    printArray(squares)


if __name__ == "__main__":
    main()

"""
Explanation:
The variables `numbers`, and `squares` hold the values that the logic checks, counts, or transforms.
The helper calculates the required result and returns it to the print statement.
The `for` loop starts with `int i = 0`, keeps running while `i < numbers.length` is true, and updates using `i++`.
"""
