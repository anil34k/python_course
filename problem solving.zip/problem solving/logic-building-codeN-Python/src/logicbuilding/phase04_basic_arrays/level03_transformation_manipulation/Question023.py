def main():
    # Question 23: : Replace every negative number with 0.
    numbers = [4, -2, 7, -8, 0, 3]

    for i in range(0, len(numbers)):
        if numbers[i] < 0:
            numbers[i] = 0

    for number in numbers:
        print(str(number) + " ", end="")
    print()


if __name__ == "__main__":
    main()

"""
Explanation:
The value stored in `numbers` is the input that the conditions or loops work on.
The enhanced `for` loop visits every element in the array one by one.
The condition `numbers[i] < 0` decides whether the current value matches the requirement.
`System.out.println()` is used only to move to the next line after the pattern output is complete.
"""
