def main():
    # Question 7: : Count how many elements are even and odd.
    numbers = [4, -2, 7, 0, 7, 3]
    even = 0
    odd = 0
    for number in numbers:
        if number % 2 == 0:
            even += 1
        else:
            odd += 1
    print("Even = " + str(even) + ", Odd = " + str(odd))


if __name__ == "__main__":
    main()

"""
Explanation:
The variables `even`, and `numbers` hold the values that the logic checks, counts, or transforms.
The enhanced `for` loop visits every element in the array one by one.
The condition `number % 2 == 0` decides whether the current value matches the requirement.
The print statement shows each value as soon as that value is calculated inside the loop.
"""
