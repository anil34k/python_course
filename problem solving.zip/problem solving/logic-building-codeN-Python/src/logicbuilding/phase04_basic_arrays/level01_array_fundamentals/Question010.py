def main():
    # Question 10: : Take n elements and print only those greater than a given value k.
    numbers = [4, -2, 7, 0, 7, 3]
    k = 3
    for number in numbers:
        if number > k:
            print(number)


if __name__ == "__main__":
    main()

"""
Explanation:
The variables `k`, and `numbers` hold the values that the logic checks, counts, or transforms.
The enhanced `for` loop visits every element in the array one by one.
The condition `number > k` decides whether the current value matches the requirement.
The print statement shows each value as soon as that value is calculated inside the loop.
"""
