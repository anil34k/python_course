def main():
    # Question 9: : Find the index of the minimum element.
    numbers = [4, -2, 7, 0, 9, 3]
    minIndex = 0

    for i in range(1, len(numbers)):
        if numbers[i] < numbers[minIndex]:
            minIndex = i

    print("Index of minimum = " + str(minIndex))


if __name__ == "__main__":
    main()

"""
Explanation:
The variables `minIndex`, and `numbers` hold the values that the logic checks, counts, or transforms.
The `for` loop starts with `int i = 1`, keeps running while `i < numbers.length` is true, and updates using `i++`.
The condition `numbers[i] < numbers[minIndex]` decides whether the current value matches the requirement.
The print statement shows each value as soon as that value is calculated inside the loop.
"""
