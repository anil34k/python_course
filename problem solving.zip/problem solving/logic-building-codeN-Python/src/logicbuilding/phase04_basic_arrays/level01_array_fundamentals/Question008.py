def main():
    # Question 8: : Find the index of the maximum element.
    numbers = [4, -2, 7, 0, 9, 3]
    maxIndex = 0

    for i in range(1, len(numbers)):
        if numbers[i] > numbers[maxIndex]:
            maxIndex = i

    print("Index of maximum = " + str(maxIndex))


if __name__ == "__main__":
    main()

"""
Explanation:
The variables `maxIndex`, and `numbers` hold the values that the logic checks, counts, or transforms.
The `for` loop starts with `int i = 1`, keeps running while `i < numbers.length` is true, and updates using `i++`.
The condition `numbers[i] > numbers[maxIndex]` decides whether the current value matches the requirement.
The print statement shows each value as soon as that value is calculated inside the loop.
"""
