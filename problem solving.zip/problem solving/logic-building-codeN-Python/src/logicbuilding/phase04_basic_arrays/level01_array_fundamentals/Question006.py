def main():
    # Question 6: : Count how many elements are positive, negative, or zero.
    number = -7
    if number > 0:
        print("Positive")
    elif number < 0:
        print("Negative")
    else:
        print("Zero")


if __name__ == "__main__":
    main()

"""
Explanation:
The value stored in `number` is the input that the conditions or loops work on.
The if/else checks test the important cases in order: `number > 0`, `number < 0`.
Only the branch whose condition becomes true prints its message.
"""
