def main():
    # Question 13: : Find the first occurrence of a given number.
    numbers = [4, 7, 2, 7, 9, 7]
    target = 7
    firstIndex = -1

    for i in range(0, len(numbers)):
        if numbers[i] == target:
            firstIndex = i
            break

    print("First occurrence = " + str(firstIndex))


if __name__ == "__main__":
    main()

"""
Explanation:
The variables `target`, `firstIndex`, and `numbers` hold the values that the logic checks, counts, or transforms.
The `for` loop starts with `int i = 0`, keeps running while `i < numbers.length` is true, and updates using `i++`.
The condition `numbers[i] == target` decides whether the current value matches the requirement.
The print statement shows each value as soon as that value is calculated inside the loop.
"""
