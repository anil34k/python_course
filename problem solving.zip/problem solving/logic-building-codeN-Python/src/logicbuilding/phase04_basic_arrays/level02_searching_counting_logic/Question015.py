def main():
    # Question 15: : Check if all elements in an array are unique.
    numbers = [4, -2, 7, 0, 7, 3]
    unique = True
    for i in range(0, len(numbers)):
        for j in range(i + 1, len(numbers)):
            if numbers[i] == numbers[j]:
                unique = False
print("All unique" if unique else "Duplicates found")


if __name__ == "__main__":
    main()

"""
Explanation:
The variables `unique`, and `numbers` hold the values that the logic checks, counts, or transforms.
The `for` loop starts with `int i = 0`, keeps running while `i < numbers.length` is true, and updates using `i++`.
The condition `numbers[i] == numbers[j]` decides whether the current value matches the requirement.
The print statement shows each value as soon as that value is calculated inside the loop.
"""
