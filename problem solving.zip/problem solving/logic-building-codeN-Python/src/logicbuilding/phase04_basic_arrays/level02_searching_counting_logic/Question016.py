def main():
    # Question 16: : Find the sum of even elements only.
    numbers = [4, -2, 7, 0, 7, 3]
    sum = 0
    for number in numbers:
        if number % 2 == 0:
            sum += number
    print("Even sum = " + str(sum))


if __name__ == "__main__":
    main()

"""
Explanation:
The value stored in `numbers` is the input that the conditions or loops work on.
The enhanced `for` loop visits every element in the array one by one.
The variable `sum` starts at 0 and collects values as the loop finds numbers that should be included.
The print statement shows each value as soon as that value is calculated inside the loop.
"""
