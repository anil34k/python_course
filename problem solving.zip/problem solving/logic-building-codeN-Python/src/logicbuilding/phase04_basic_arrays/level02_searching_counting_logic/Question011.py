def main():
    # Question 11: : Input an element x - check if it exists in the array.
    numbers = [4, -2, 7, 0, 7, 3]
    x = 7
    found = False
    for number in numbers:
        if number == x:
            found = True
    print("Exists" if found else "Does not exist")


if __name__ == "__main__":
    main()

"""
Explanation:
The variables `x`, and `numbers` hold the values that the logic checks, counts, or transforms.
The enhanced `for` loop visits every element in the array one by one.
The boolean `found` starts as false and becomes true as soon as the searched value is seen.
The condition `number == x` decides whether the current value matches the requirement.
The print statement shows each value as soon as that value is calculated inside the loop.
"""
