def main():
    # Question 12: : Count how many times a given element appears.
    numbers = [4, 7, 2, 7, 9, 7]
    target = 7
    count = 0

    for number in numbers:
        if number == target:
            count += 1

    print("Frequency = " + str(count))


if __name__ == "__main__":
    main()

"""
Explanation:
We keep the array in `numbers`, choose the value to search for in `target`, and start `count` from 0.
The enhanced `for` loop checks every array element one by one.
Whenever `number == target` is true, the code increases `count`.
After the loop finishes, `count` contains the total frequency of the target element.
"""
