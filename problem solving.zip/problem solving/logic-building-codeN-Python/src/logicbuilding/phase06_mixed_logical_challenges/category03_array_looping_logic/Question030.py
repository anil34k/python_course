def main():
    # Question 30: : Find the sum of all elements at odd indices.
    numbers = [4, -2, 7, 0, 7, 3]
    sum = 0
    i = 1
    while i < len(numbers):
        sum += numbers[i]
        i += 2
    print("Sum = " + str(sum))


if __name__ == "__main__":
    main()

"""
Explanation:
The value stored in `numbers` is the input that the conditions or loops work on.
The `for` loop starts with `int i = 1`, keeps running while `i < numbers.length` is true, and updates using `i += 2`.
The variable `sum` starts at 0 and collects values as the loop finds numbers that should be included.
The print statement shows each value as soon as that value is calculated inside the loop.
"""
