def main():
    # Question 26: : Count how many elements are even at an even index.
    numbers = [4, -2, 7, 0, 7, 3]
    count = 0
    i = 0
    while i < len(numbers):
        if numbers[i] % 2 == 0:
            count += 1
        i += 2
    print("Count = " + str(count))


if __name__ == "__main__":
    main()

"""
Explanation:
The value stored in `numbers` is the input that the conditions or loops work on.
The `for` loop starts with `int i = 0`, keeps running while `i < numbers.length` is true, and updates using `i += 2`.
The variable `count` starts at 0 and increases only when the current item satisfies the question's condition.
The condition `numbers[i] % 2 == 0` decides whether the current value matches the requirement.
The print statement shows each value as soon as that value is calculated inside the loop.
"""
