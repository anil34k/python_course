def printArray(values):
    for value in values:
        print(str(value) + " ", end="")
    print()

def main():
    # Question 29: : Rotate an array by one position to the right.
    numbers = [4, -2, 7, 0, 7, 3]
    last = numbers[len(numbers) - 1]
    i = len(numbers) - 1
    while i > 0:
        numbers[i] = numbers[i - 1]
        i -= 1
    numbers[0] = last
    printArray(numbers)


if __name__ == "__main__":
    main()

"""
Explanation:
The variables `last`, and `numbers` hold the values that the logic checks, counts, or transforms.
The helper calculates the required result and returns it to the print statement.
The `for` loop starts with `int i = numbers.length - 1`, keeps running while `i > 0` is true, and updates using `i--`.
"""
