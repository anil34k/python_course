def printArray(values):
    for value in values:
        print(str(value) + " ", end="")
    print()

def main():
    # Question 25: : Shift all zeros to the end of the array.
    numbers = [0, 4, 0, 5, 7, 0]
    index = 0
    for number in numbers:
        if number != 0:
            numbers[index] = number
            index += 1
    while index < len(numbers):
        numbers[index] = 0
        index += 1
    printArray(numbers)


if __name__ == "__main__":
    main()

"""
Explanation:
The variables `index`, and `numbers` hold the values that the logic checks, counts, or transforms.
The helper calculates the required result and returns it to the print statement.
The enhanced `for` loop visits every element in the array one by one.
The `while` or `do-while` loop keeps repeating until the changing value reaches the stopping condition.
"""
