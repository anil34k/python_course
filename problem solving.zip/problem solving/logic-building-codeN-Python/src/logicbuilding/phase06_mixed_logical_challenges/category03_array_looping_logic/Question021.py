def max(values):
    answer = values[0]
    for value in values:
        if value > answer:
            answer = value
    return answer

def min(values):
    answer = values[0]
    for value in values:
        if value < answer:
            answer = value
    return answer

def main():
    # Question 21: : Find the maximum and minimum element in an array.
    numbers = [4, -2, 7, 0, 7, 3]
    print("Maximum = " + str(max(numbers)))
    print("Minimum = " + str(min(numbers)))


if __name__ == "__main__":
    main()

"""
Explanation:
The value stored in `numbers` is the input that the conditions or loops work on.
The helper calculates the required result and returns it to the print statement.
The calculated answer is printed after the logic produces the final value.
"""
