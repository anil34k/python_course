def main():
    # Question 33: : Print all subarrays of a given array.
    numbers = [1, 2, 3]
    for start in range(0, len(numbers)):
        for end in range(start, len(numbers)):
            for i in range(start, end + 1):
                print(str(numbers[i]) + " ", end="")
            print()


if __name__ == "__main__":
    main()

"""
Explanation:
The variables `start`, `end`, and `numbers` hold the values that the logic checks, counts, or transforms.
The `for` loop starts with `int start = 0`, keeps running while `start < numbers.length` is true, and updates using `start++`.
`System.out.println()` is used only to move to the next line after the pattern output is complete.
"""
