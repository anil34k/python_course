def main():
    # Question 37: : Print pattern of increasing characters (A, AB, ABC...).
    text = "logic"
    print(text)


if __name__ == "__main__":
    main()

"""
Explanation:
The value stored in `text` is the input that the conditions or loops work on.
The calculated answer is printed after the logic produces the final value.
"""
