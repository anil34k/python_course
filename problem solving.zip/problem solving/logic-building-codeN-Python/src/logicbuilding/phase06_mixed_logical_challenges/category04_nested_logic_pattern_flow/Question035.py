def main():
    # Question 35: : Count how many times a number appears consecutively in an array.
    numbers = [2, 2, 2, 3, 3, 4]
    target = 2
    maxRun = 0
    currentRun = 0
    for number in numbers:
        if number == target:
            currentRun += 1
        else:
            currentRun = 0
        if currentRun > maxRun:
            maxRun = currentRun
    print("Longest consecutive count = " + str(maxRun))


if __name__ == "__main__":
    main()

"""
Explanation:
The variables `target`, and `numbers` hold the values that the logic checks, counts, or transforms.
The enhanced `for` loop visits every element in the array one by one.
The if/else checks test the important cases in order: `number == target`, `currentRun > maxRun`.
The print statement shows each value as soon as that value is calculated inside the loop.
"""
