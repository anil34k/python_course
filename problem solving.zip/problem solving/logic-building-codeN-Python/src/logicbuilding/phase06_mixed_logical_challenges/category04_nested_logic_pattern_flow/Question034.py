def printArray(values):
    for value in values:
        print(str(value) + " ", end="")
    print()

def main():
    # Question 34: : Check if an array is sorted (ascending or descending).
    numbers = [4, -2, 7, 0, 7, 3]
    printArray(numbers)


if __name__ == "__main__":
    main()

"""
Explanation:
The value stored in `numbers` is the input that the conditions or loops work on.
The helper calculates the required result and returns it to the print statement.
"""
