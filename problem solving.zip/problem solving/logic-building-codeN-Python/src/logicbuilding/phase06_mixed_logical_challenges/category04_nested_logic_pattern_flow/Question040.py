def main():
    # Question: Print spiral number matrix up to N x N.
    n = 4
    matrix = [[0 for _ in range(n)] for _ in range(n)]
    value = 1
    top, bottom, left, right = 0, n - 1, 0, n - 1
    while top <= bottom and left <= right:
        for col in range(left, right + 1):
            matrix[top][col] = value; value += 1
        top += 1
        for row in range(top, bottom + 1):
            matrix[row][right] = value; value += 1
        right -= 1
        for col in range(right, left - 1, -1):
            matrix[bottom][col] = value; value += 1
        bottom -= 1
        for row in range(bottom, top - 1, -1):
            matrix[row][left] = value; value += 1
        left += 1
    for row in matrix:
        print(*row)


if __name__ == "__main__":
    main()

"""
Explanation:
The value stored in `n` is the input that the conditions or loops work on.
The helper calculates the required result and returns it to the print statement.
The outer loop controls each row of the pattern, and the inner loop controls what gets printed inside that row.
The `while` or `do-while` loop keeps repeating until the changing value reaches the stopping condition.
"""
