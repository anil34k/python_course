def isArmstrong(number):
    value = number
    digits = 0
    while True:
        digits += 1
        value //= 10
        if not (value > 0):
            break
    sum = 0
    value = number
    while True:
        digit = value % 10
        power = 1
        for i in range(1, digits + 1):
            power *= digit
        sum += power
        value //= 10
        if not (value > 0):
            break
    return sum == number

def main():
    # Question 3: : Check if a number is an Armstrong number.
    number = 153
    print("Armstrong number" if isArmstrong(number) else "Not Armstrong number")


if __name__ == "__main__":
    main()

"""
Explanation:
The value stored in `number` is the input that the conditions or loops work on.
The helper counts how many digits the number has by repeatedly dividing a copy of the number by 10.
Then it extracts each digit with `% 10`, raises that digit to the digit-count power, and adds it to `sum`.
If the final `sum` equals the original number, the helper returns true.
The calculated answer is printed after the logic produces the final value.
"""
