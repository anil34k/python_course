def isPrime(number):
    if number <= 1:
        return False
    divisor = 2
    while divisor * divisor <= number:
        if number % divisor == 0:
            return False
        divisor += 1
    return True

def main():
    # Question 7: : Print all prime numbers between 1 and N.
    n = 100
    for number in range(2, n + 1):
        if isPrime(number):
            print(number)


if __name__ == "__main__":
    main()

"""
Explanation:
The value stored in `n` is the input that the conditions or loops work on.
The helper tries possible divisors from 2 up to the square root of the number.
If any divisor divides the number exactly, the number is not prime; otherwise it is prime.
The `for` loop starts with `int number = 2`, keeps running while `number <= n` is true, and updates using `number++`.
The condition `isPrime(number)` decides whether the current value matches the requirement.
The print statement shows each value as soon as that value is calculated inside the loop.
"""
