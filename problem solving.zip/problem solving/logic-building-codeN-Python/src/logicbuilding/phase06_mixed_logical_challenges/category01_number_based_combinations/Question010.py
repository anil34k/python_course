def main():
    # Question 10: : Check if a number is perfect (sum of factors equals number).
    number = 28
    sum = 0

    for factor in range(1, number):
        if number % factor == 0:
            sum += factor

    print("Perfect number" if sum == number else "Not perfect number")


if __name__ == "__main__":
    main()

"""
Explanation:
The variables `number`, `sum`, and `factor` hold the values that the logic checks, counts, or transforms.
The `for` loop starts with `int factor = 1`, keeps running while `factor < number` is true, and updates using `factor++`.
The variable `sum` starts at 0 and collects values as the loop finds numbers that should be included.
The condition `number % factor == 0` decides whether the current value matches the requirement.
The print statement shows each value as soon as that value is calculated inside the loop.
"""
