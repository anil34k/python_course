def main():
    # Question 9: : Check if a number is palindrome (121 -> true).
    number = 121
    value = number
    reversed = 0

    while value > 0:
        digit = value % 10
        reversed = reversed * 10 + digit
        value //= 10

    print("Palindrome" if number == reversed else "Not palindrome")


if __name__ == "__main__":
    main()

"""
Explanation:
The value stored in `reversed` is the input that the conditions or loops work on.
The loop uses `% 10` to take the last digit and `/= 10` to remove that digit, which is the standard digit-processing pattern.
The calculated answer is printed after the logic produces the final value.
"""
