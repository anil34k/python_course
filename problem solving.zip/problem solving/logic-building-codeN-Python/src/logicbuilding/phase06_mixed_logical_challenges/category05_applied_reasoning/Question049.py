def printArray(values):
    for value in values:
        print(str(value) + " ", end="")
    print()

def main():
    # Question 49: : Count how many prime numbers are there in an array.
    numbers = [4, -2, 7, 0, 7, 3]
    printArray(numbers)


if __name__ == "__main__":
    main()

"""
Explanation:
The value stored in `numbers` is the input that the conditions or loops work on.
The helper tries possible divisors from 2 up to the square root of the number.
If any divisor divides the number exactly, the number is not prime; otherwise it is prime.
"""
