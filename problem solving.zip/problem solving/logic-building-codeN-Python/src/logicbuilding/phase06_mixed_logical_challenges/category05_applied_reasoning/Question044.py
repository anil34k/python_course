def main():
    # Question: Build a basic calculator using operator input.
    first = 12
    second = 4
    operator = '+'
    if operator == '+':
        print(first + second)
    elif operator == '-':
        print(first - second)
    elif operator == '*':
        print(first * second)
    elif operator == '/':
        print(first // second)
    else:
        print("Invalid operator")


if __name__ == "__main__":
    main()

"""
Explanation:
The variables `first`, and `operator` hold the values that the logic checks, counts, or transforms.
The calculated answer is printed after the logic produces the final value.
"""
