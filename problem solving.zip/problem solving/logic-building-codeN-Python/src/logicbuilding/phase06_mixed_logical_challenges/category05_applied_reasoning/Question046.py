def main():
    # Question 46: : Print frequency of each digit in a number.
    number = 122333045
    frequency = [0] * (10)
    value = number

    while value > 0:
        digit = value % 10
        frequency[digit] += 1
        value //= 10

    for digit in range(0, len(frequency)):
        if frequency[digit] > 0:
            print(str(digit) + " appears " + str(frequency[digit]) + " times")


if __name__ == "__main__":
    main()

"""
Explanation:
We store the sample number in `number` and create a `frequency` array with 10 positions, one for each digit from 0 to 9.
The `while` loop extracts the last digit using `% 10` and then removes it using `/= 10`.
For every extracted digit, `frequency[digit]++` increases the counter for that exact digit.
The final `for` loop goes through the frequency array and prints only the digits that appeared at least once.
"""
