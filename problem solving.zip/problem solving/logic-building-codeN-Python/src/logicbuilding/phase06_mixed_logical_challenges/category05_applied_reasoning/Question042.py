def main():
    # Question 42: : Take age inputs and count how many are adults, minors, seniors.
    ages = [12, 18, 35, 61, 8, 75]
    minors = 0
    adults = 0
    seniors = 0

    for age in ages:
        if age < 18:
            minors += 1
        elif age >= 60:
            seniors += 1
        else:
            adults += 1

    print("Minors = " + str(minors))
    print("Adults = " + str(adults))
    print("Seniors = " + str(seniors))


if __name__ == "__main__":
    main()

"""
Explanation:
The variables `minors`, `adults`, `seniors`, and `ages` hold the values that the logic checks, counts, or transforms.
The `for` loop starts with `int age : ages) { if (age < 18) { minors++`, keeps running while `} else if (age >= 60) { seniors++` is true, and updates using `} else { adults++; } } System.out.println("Minors = " + minors`.
The if/else checks test the important cases in order: `age < 18`, `age >= 60`.
The print statement shows each value as soon as that value is calculated inside the loop.
"""
