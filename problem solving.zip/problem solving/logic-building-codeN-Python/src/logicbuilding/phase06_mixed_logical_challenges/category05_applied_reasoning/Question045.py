def main():
    # Question 45: : Count how many times a coin lands on heads/tails (use random).
    results = {"H", "T", "H", "H", "T"}
    heads = 0
    tails = 0
    for result in results:
        if result.equals("H"):
            heads += 1
        else:
            tails += 1
    print("Heads = " + str(heads) + ", Tails = " + str(tails))


if __name__ == "__main__":
    main()

"""
Explanation:
The variables `heads`, and `results` hold the values that the logic checks, counts, or transforms.
The `for` loop starts with `String result : results) { if (result.equals("H")) heads++`, keeps running while `else tails++` is true, and updates using `} System.out.println("Heads = " + heads + ", Tails = " + tails`.
The condition `result.equals("H")` decides whether the current value matches the requirement.
The print statement shows each value as soon as that value is calculated inside the loop.
"""
