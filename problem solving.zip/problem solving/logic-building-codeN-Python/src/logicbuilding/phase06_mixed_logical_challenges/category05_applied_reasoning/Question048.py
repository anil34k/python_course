def main():
    # Question 48: : Print characters that are common in two strings.
    first = "logic"
    second = "coding"
    for i in range(0, len(first)):
        ch = first[i]
        if second.find(ch) >= 0 and first.find(ch) == i:
            print(ch)


if __name__ == "__main__":
    main()

"""
Explanation:
The variables `first`, `second`, and `ch` hold the values that the logic checks, counts, or transforms.
The `for` loop starts with `int i = 0`, keeps running while `i < first.length()` is true, and updates using `i++`.
`charAt(i)` lets the code inspect one character at a time by index.
The condition `second.indexOf(ch) >= 0 && first.indexOf(ch) == i` decides whether the current value matches the requirement.
The print statement shows each value as soon as that value is calculated inside the loop.
"""
