def main():
    # Question 41: : Given marks of students, find how many passed (>= 40).
    marks = [35, 40, 76, 22, 90]
    passed = 0
    for mark in marks:
        if mark >= 40:
            passed += 1
    print("Passed = " + str(passed))


if __name__ == "__main__":
    main()

"""
Explanation:
The variables `passed`, and `marks` hold the values that the logic checks, counts, or transforms.
The loop repeats the same check or calculation for every required value.
The condition `mark >= 40` decides whether the current value matches the requirement.
The print statement shows each value as soon as that value is calculated inside the loop.
"""
