def isPalindromeString(text):
    cleaned = text.replace(" ", "").lower()
    left = 0
    right = len(cleaned) - 1
    while left < right:
        if cleaned[left] != cleaned[right]:
            return False
        left += 1
        right -= 1
    return True

def main():
    # Question 50: : Print all palindromic words from a sentence.
    sentence = "madam and level are words"
    for word in sentence.split():
        if isPalindromeString(word):
            print(word)


if __name__ == "__main__":
    main()

"""
Explanation:
The value stored in `sentence` is the input that the conditions or loops work on.
The helper calculates the required result and returns it to the print statement.
The loop goes word by word after splitting the sentence, so each word can be checked separately.
`split("\\s+")` breaks the sentence wherever spaces appear, giving us separate words to process.
The condition `isPalindromeString(word)` decides whether the current value matches the requirement.
The print statement shows each value as soon as that value is calculated inside the loop.
"""
