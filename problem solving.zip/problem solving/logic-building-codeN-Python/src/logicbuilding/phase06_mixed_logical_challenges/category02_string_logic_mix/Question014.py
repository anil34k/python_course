def is_vowel(ch):
    return ch.lower() in "aeiou"

def main():
    # Question: Replace each vowel with its vowel position.
    text = "education"
    result = ""
    for ch in text:
        result += str("aeiou".index(ch.lower()) + 1) if is_vowel(ch) else ch
    print(result)


if __name__ == "__main__":
    main()

"""
Explanation:
The variables `text`, and `ch` hold the values that the logic checks, counts, or transforms.
The helper checks characters against `a`, `e`, `i`, `o`, and `u`, so the main loop only needs to use that true/false result.
The `for` loop starts with `int i = 0`, keeps running while `i < text.length()` is true, and updates using `i++`.
A `StringBuilder` is used so characters or words can be added gradually while building the final string.
`charAt(i)` lets the code inspect one character at a time by index.
The print statement shows each value as soon as that value is calculated inside the loop.
"""
