def main():
    # Question 20: : Remove duplicate words from a sentence.
    words = "java logic java code".split()
    result = ""
    for i in range(0, len(words)):
        seen = False
        for j in range(0, i):
            if words[i].equals(words[j]):
                seen = True
        if not seen:
            result += str(words[i]).append(" ")
    print(result.toString().strip())


if __name__ == "__main__":
    main()

"""
Explanation:
The variables `seen`, and `words` hold the values that the logic checks, counts, or transforms.
The `for` loop starts with `int i = 0`, keeps running while `i < words.length` is true, and updates using `i++`.
A `StringBuilder` is used so characters or words can be added gradually while building the final string.
`split("\\s+")` breaks the sentence wherever spaces appear, giving us separate words to process.
The condition `words[i].equals(words[j])` decides whether the current value matches the requirement.
The print statement shows each value as soon as that value is calculated inside the loop.
"""
