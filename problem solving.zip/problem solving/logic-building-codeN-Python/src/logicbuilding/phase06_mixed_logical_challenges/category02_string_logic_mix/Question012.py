def isVowel(ch):
    lower = ch.lower()
    return lower == 'a' or lower == 'e' or lower == 'i' or lower == 'o' or lower == 'u'

def countVowels(text):
    count = 0
    for i in range(0, len(text)):
        if isVowel(text[i]):
            count += 1
    return count

def main():
    # Question 12: : Count vowels in each word of a sentence.
    sentence = "logic building"
    for word in sentence.split():
        print(str(word) + " -> " + str(countVowels(word)))


if __name__ == "__main__":
    main()

"""
Explanation:
The value stored in `sentence` is the input that the conditions or loops work on.
The helper checks characters against `a`, `e`, `i`, `o`, and `u`, so the main loop only needs to use that true/false result.
The loop goes word by word after splitting the sentence, so each word can be checked separately.
`split("\\s+")` breaks the sentence wherever spaces appear, giving us separate words to process.
The print statement shows each value as soon as that value is calculated inside the loop.
"""
