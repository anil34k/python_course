def main():
    # Question 11: : Check if two strings are anagrams (without using collections).
    first = "listen"
    second = "silent"
    frequency = [0] * (256)
    for i in range(0, len(first)):
        frequency[first.charAt(i)] += 1
    for i in range(0, len(second)):
        frequency[second.charAt(i)] -= 1
    anagram = len(first) == len(second)
    for value in frequency:
        if value != 0:
            anagram = False
    print("Anagram" if anagram else "Not anagram")


if __name__ == "__main__":
    main()

"""
Explanation:
The variables `first`, `second`, and `anagram` hold the values that the logic checks, counts, or transforms.
The `for` loop starts with `int i = 0`, keeps running while `i < first.length()` is true, and updates using `i++`.
`charAt(i)` lets the code inspect one character at a time by index.
The condition `value != 0` decides whether the current value matches the requirement.
The print statement shows each value as soon as that value is calculated inside the loop.
"""
