def main():
    # Question 18: : Check if two strings are rotations of each other.
    first = "abcd"
    second = "cdab"
    print("Rotation" if (len(first) == len(second) and (first + first).contains(second)) else "Not rotation")


if __name__ == "__main__":
    main()

"""
Explanation:
The variables `first`, and `second` hold the values that the logic checks, counts, or transforms.
The calculated answer is printed after the logic produces the final value.
"""
