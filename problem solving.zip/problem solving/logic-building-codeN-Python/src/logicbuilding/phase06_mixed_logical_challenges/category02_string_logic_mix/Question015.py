def main():
    # Question 15: : Print characters that appear more than once (without map).
    text = "programming"
    for i in range(0, len(text)):
        count = 0
        for j in range(0, len(text)):
            if text[i] == text[j]:
                count += 1
        if count > 1 and text.find(text[i]) == i:
            print(text[i])


if __name__ == "__main__":
    main()

"""
Explanation:
The value stored in `text` is the input that the conditions or loops work on.
The `for` loop starts with `int i = 0`, keeps running while `i < text.length()` is true, and updates using `i++`.
The variable `count` starts at 0 and increases only when the current item satisfies the question's condition.
`charAt(i)` lets the code inspect one character at a time by index.
The if/else checks test the important cases in order: `text.charAt(i) == text.charAt(j)`, `count > 1 && text.indexOf(text.charAt(i)) == i`.
The print statement shows each value as soon as that value is calculated inside the loop.
"""
