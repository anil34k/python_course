def main():
    # Question: Toggle case for every alternate word in a sentence.
    words = "logic building is fun".split()
    for i in range(len(words)):
        print(words[i].upper() if i % 2 == 0 else words[i].lower(), end=" ")
    print()


if __name__ == "__main__":
    main()

"""
Explanation:
The value stored in `words` is the input that the conditions or loops work on.
The `for` loop starts with `int i = 0`, keeps running while `i < words.length` is true, and updates using `i++`.
`split("\\s+")` breaks the sentence wherever spaces appear, giving us separate words to process.
The condition `i % 2 == 0` decides whether the current value matches the requirement.
`System.out.println()` is used only to move to the next line after the pattern output is complete.
"""
