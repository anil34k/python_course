def main():
    # Question 41: : Take coordinates (x, y) and check if the point lies on the X-axis, Y-axis, or at the origin.
    x = 0
    y = 5
    if x == 0 and y == 0:
        print("Origin")
    elif y == 0:
        print("X-axis")
    elif x == 0:
        print("Y-axis")
    else:
        print("Not on an axis")


if __name__ == "__main__":
    main()

"""
Explanation:
The value stored in `x` is the input that the conditions or loops work on.
The if/else checks test the important cases in order: `x == 0 && y == 0`, `y == 0`, `x == 0`.
Only the branch whose condition becomes true prints its message.
"""
