def main():
    # Question 42: : Take three numbers and check if they can form a Pythagorean triplet.
    a = 3
    b = 4
    c = 5
    if a * a + b * b == c * c or a * a + c * c == b * b or b * b + c * c == a * a:
        print("Pythagorean triplet")
    else:
        print("Not a Pythagorean triplet")


if __name__ == "__main__":
    main()

"""
Explanation:
The value stored in `a` is the input that the conditions or loops work on.
The condition `a * a + b * b == c * c || a * a + c * c == b * b || b * b + c * c == a * a` decides whether the current value matches the requirement.
Only the branch whose condition becomes true prints its message.
"""
