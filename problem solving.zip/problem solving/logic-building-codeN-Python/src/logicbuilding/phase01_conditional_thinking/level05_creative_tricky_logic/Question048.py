def sumDigits(number):
    value = abs(number)
    sum = 0
    while True:
        sum += value % 10
        value //= 10
        if not (value > 0):
            break
    return sum

def productDigits(number):
    value = abs(number)
    product = 1
    if value == 0:
        return 0
    while value > 0:
        product *= value % 10
        value //= 10
    return product

def main():
    # Question 48: : Take an integer (1-9999) and check if the sum of its digits is greater than the product of its digits.
    number = 1234
    sum = sumDigits(number)
    product = productDigits(number)
    if sum > product:
        print("Digit sum is greater")
    else:
        print("Digit product is greater or equal")


if __name__ == "__main__":
    main()

"""
Explanation:
The variables `number`, `sum`, and `product` hold the values that the logic checks, counts, or transforms.
The helper calculates the required result and returns it to the print statement.
The condition `sum > product` decides whether the current value matches the requirement.
Only the branch whose condition becomes true prints its message.
"""
