def main():
    # Question 49: : Take two dates (day and month) and determine which one comes first in the calendar.
    day1 = 12
    month1 = 5
    day2 = 10
    month2 = 6
    if month1 < month2 or (month1 == month2 and day1 < day2):
        print("First date comes first")
    elif month1 == month2 and day1 == day2:
        print("Both dates are same")
    else:
        print("Second date comes first")


if __name__ == "__main__":
    main()

"""
Explanation:
The variables `day1`, and `day2` hold the values that the logic checks, counts, or transforms.
The if/else checks test the important cases in order: `month1 < month2 || (month1 == month2 && day1 < day2)`, `month1 == month2 && day1 == day2`.
Only the branch whose condition becomes true prints its message.
"""
