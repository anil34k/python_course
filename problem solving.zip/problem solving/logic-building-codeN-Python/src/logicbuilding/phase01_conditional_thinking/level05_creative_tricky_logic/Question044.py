def main():
    # Question 44: : Take time (hours and minutes) and print the smaller angle between the hour and minute hands.
    hours = 3
    minutes = 30
    hourAngle = (hours % 12) * 30 + minutes * 0.5
    minuteAngle = minutes * 6
    angle = abs(hourAngle - minuteAngle)
    if angle > 180:
        angle = 360 - angle
    print("Smaller angle = " + str(angle))


if __name__ == "__main__":
    main()

"""
Explanation:
The variables `hours`, `minutes`, `hourAngle`, and `minuteAngle` hold the values that the logic checks, counts, or transforms.
The condition `angle > 180` decides whether the current value matches the requirement.
Only the branch whose condition becomes true prints its message.
"""
