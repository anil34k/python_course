def main():
    # Question 45: : Take three numbers and check if they are in arithmetic progression.
    a = 4
    b = 8
    c = 12
    if b - a == c - b:
        print("Arithmetic progression")
    else:
        print("Not an arithmetic progression")


if __name__ == "__main__":
    main()

"""
Explanation:
The value stored in `a` is the input that the conditions or loops work on.
The condition `b - a == c - b` decides whether the current value matches the requirement.
Only the branch whose condition becomes true prints its message.
"""
