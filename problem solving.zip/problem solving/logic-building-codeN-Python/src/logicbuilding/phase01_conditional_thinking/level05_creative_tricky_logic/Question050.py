def main():
    # Question 50: : Take a year and print the corresponding century (e.g., "19th century", "20th century").
    year = 1998
    century = (year + 99) // 100
    print(str(century) + "th century")


if __name__ == "__main__":
    main()

"""
Explanation:
The variables `year`, and `century` hold the values that the logic checks, counts, or transforms.
The calculated answer is printed after the logic produces the final value.
"""
