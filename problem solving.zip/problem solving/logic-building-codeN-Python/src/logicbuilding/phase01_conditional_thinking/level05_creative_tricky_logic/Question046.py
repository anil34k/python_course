def main():
    # Question 46: : Take three numbers and check if they are in geometric progression.
    a = 3
    b = 9
    c = 27
    if b * b == a * c:
        print("Geometric progression")
    else:
        print("Not a geometric progression")


if __name__ == "__main__":
    main()

"""
Explanation:
The value stored in `a` is the input that the conditions or loops work on.
The condition `b * b == a * c` decides whether the current value matches the requirement.
Only the branch whose condition becomes true prints its message.
"""
