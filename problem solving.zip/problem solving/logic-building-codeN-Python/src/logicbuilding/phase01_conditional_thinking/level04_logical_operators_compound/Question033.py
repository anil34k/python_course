def main():
    # Question 33: : Take three numbers and print the median value (neither maximum nor minimum).
    a = 12
    b = 5
    c = 20
    median = 0
    if (a >= b and a <= c) or (a >= c and a <= b):
        median = a
    elif (b >= a and b <= c) or (b >= c and b <= a):
        median = b
    else:
        median = c
    print("Median = " + str(median))


if __name__ == "__main__":
    main()

"""
Explanation:
The value stored in `a` is the input that the conditions or loops work on.
The if/else checks test the important cases in order: `(a >= b && a <= c) || (a >= c && a <= b)`, `(b >= a && b <= c) || (b >= c && b <= a)`.
Only the branch whose condition becomes true prints its message.
"""
