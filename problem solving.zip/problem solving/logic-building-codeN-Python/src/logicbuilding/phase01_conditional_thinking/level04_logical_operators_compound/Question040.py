def main():
    # Question 40: : Take a password string and check basic rules (length >= 8 and contains at least one digit).
    password = "Code123not "
    hasDigit = False
    hasUpper = False
    hasLower = False
    hasSpecial = False
    for i in range(0, len(password)):
        ch = password[i]
        if ch.isdigit():
            hasDigit = True
        elif ch.isupper():
            hasUpper = True
        elif ch.islower():
            hasLower = True
        else:
            hasSpecial = True
    if len(password) >= 8 and hasDigit and hasUpper and hasLower and hasSpecial:
        print("Valid password")
    else:
        print("Invalid password")


if __name__ == "__main__":
    main()

"""
Explanation:
The variables `password`, `hasDigit`, and `ch` hold the values that the logic checks, counts, or transforms.
The `for` loop starts with `int i = 0`, keeps running while `i < password.length()` is true, and updates using `i++`.
`charAt(i)` lets the code inspect one character at a time by index.
The if/else checks test the important cases in order: `Character.isDigit(ch)`, `Character.isUpperCase(ch)`, `Character.isLowerCase(ch)`.
The print statement shows each value as soon as that value is calculated inside the loop.
"""
