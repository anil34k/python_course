def main():
    # Question 37: : Take a single digit (0-9) and print its word form ("Zero" to "Nine").
    digit = 7
    words = {"Zero", "One", "Two", "Three", "Four", "Five", "Six", "Seven", "Eight", "Nine"}
    if digit >= 0 and digit <= 9:
        print(words[digit])
    else:
        print("Invalid digit")


if __name__ == "__main__":
    main()

"""
Explanation:
The value stored in `words` is the input that the conditions or loops work on.
The condition `digit >= 0 && digit <= 9` decides whether the current value matches the requirement.
Only the branch whose condition becomes true prints its message.
"""
