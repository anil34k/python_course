def main():
    # Question 34: : Take 24-hour time (hours and minutes) and print whether it is AM or PM.
    hour = 14
    minutes = 30
    if hour < 12:
        print("AM")
    else:
        print("PM")


if __name__ == "__main__":
    main()

"""
Explanation:
The variables `hour`, and `minutes` hold the values that the logic checks, counts, or transforms.
The condition `hour < 12` decides whether the current value matches the requirement.
Only the branch whose condition becomes true prints its message.
"""
