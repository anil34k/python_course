def main():
    # Question 36: : Take two numbers and check if both are positive and their sum is less than 100.
    first = 30
    second = 40
    if first > 0 and second > 0 and first + second < 100:
        print("Condition satisfied")
    else:
        print("Condition not satisfied")


if __name__ == "__main__":
    main()

"""
Explanation:
The value stored in `first` is the input that the conditions or loops work on.
The condition `first > 0 && second > 0 && first + second < 100` decides whether the current value matches the requirement.
Only the branch whose condition becomes true prints its message.
"""
