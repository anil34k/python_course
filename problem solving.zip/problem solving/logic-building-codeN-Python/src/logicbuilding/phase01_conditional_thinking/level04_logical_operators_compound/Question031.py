def main():
    # Question 31: : Take a character and check if it is a letter, a digit, or neither.
    ch = '9'
    if ch.isalpha():
        print("Letter")
    elif ch.isdigit():
        print("Digit")
    else:
        print("Neither")


if __name__ == "__main__":
    main()

"""
Explanation:
The value stored in `ch` is the input that the conditions or loops work on.
The if/else checks test the important cases in order: `Character.isLetter(ch)`, `Character.isDigit(ch)`.
Only the branch whose condition becomes true prints its message.
"""
