def main():
    # Question: Calculate electricity bill based on units using slab rates.
    units = 150
    if units <= 100:
        bill = units * 5
    elif units <= 200:
        bill = 100 * 5 + (units - 100) * 7
    else:
        bill = 100 * 5 + 100 * 7 + (units - 200) * 10
    print("Bill = " + str(bill))


if __name__ == "__main__":
    main()

"""
Explanation:
The value stored in `units` is the input that the conditions or loops work on.
The if/else checks test the important cases in order: `units <= 100`, `units <= 200`.
Only the branch whose condition becomes true prints its message.
"""
