def main():
    # Question 35: : Take income and age, and check if eligible for tax (age > 18 and income > 5 L).
    age = 25
    income = 600000
    if age > 18 and income > 500000:
        print("Eligible for tax")
    else:
        print("Not eligible for tax")


if __name__ == "__main__":
    main()

"""
Explanation:
The variables `age`, and `income` hold the values that the logic checks, counts, or transforms.
The condition `age > 18 && income > 500000` decides whether the current value matches the requirement.
Only the branch whose condition becomes true prints its message.
"""
