def main():
    # Question 27: : Check if an amount can be evenly divided into 2000, 500, and 100 currency notes.
    amount = 7600
    notes2000 = amount / 2000
    amount %= 2000
    notes500 = amount / 500
    amount %= 500
    notes100 = amount // 100
    amount %= 100
    if amount == 0:
        print("2000: " + str(notes2000) + ", 500: " + str(notes500) + ", 100: " + str(notes100))
    else:
        print("Amount cannot be fully divided into these notes")


if __name__ == "__main__":
    main()

"""
Explanation:
The variables `amount`, `notes2000`, `notes500`, and `notes100` hold the values that the logic checks, counts, or transforms.
The condition `amount == 0` decides whether the current value matches the requirement.
Only the branch whose condition becomes true prints its message.
"""
