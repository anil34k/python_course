def main():
    # Question 21: : Take a 3-digit number and check if all digits are distinct.
    number = 427
    hundreds = number // 100
    tens = (number // 10) % 10
    ones = number % 10
    if hundreds != tens and tens != ones and hundreds != ones:
        print("All digits are distinct")
    else:
        print("Digits are not distinct")


if __name__ == "__main__":
    main()

"""
Explanation:
The variables `hundreds`, `tens`, and `ones` hold the values that the logic checks, counts, or transforms.
The condition `hundreds != tens && tens != ones && hundreds != ones` decides whether the current value matches the requirement.
Only the branch whose condition becomes true prints its message.
"""
