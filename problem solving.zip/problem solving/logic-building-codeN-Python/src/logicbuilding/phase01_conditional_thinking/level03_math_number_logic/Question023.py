def main():
    # Question 23: : Take a 4-digit number and check if the first and last digits are equal.
    number = 4554
    firstDigit = number // 1000
    lastDigit = number % 10
    if firstDigit == lastDigit:
        print("First and last digits are equal")
    else:
        print("First and last digits are not equal")


if __name__ == "__main__":
    main()

"""
Explanation:
The variables `firstDigit`, and `lastDigit` hold the values that the logic checks, counts, or transforms.
The condition `firstDigit == lastDigit` decides whether the current value matches the requirement.
Only the branch whose condition becomes true prints its message.
"""
