def main():
    # Question 24: : Check whether a given integer is single-digit, double-digit, or multi-digit.
    number = 87
    value = abs(number)
    if value <= 9:
        print("Single-digit")
    elif value <= 99:
        print("Double-digit")
    else:
        print("Multi-digit")


if __name__ == "__main__":
    main()

"""
Explanation:
The variables `number`, and `value` hold the values that the logic checks, counts, or transforms.
The if/else checks test the important cases in order: `value <= 9`, `value <= 99`.
Only the branch whose condition becomes true prints its message.
"""
