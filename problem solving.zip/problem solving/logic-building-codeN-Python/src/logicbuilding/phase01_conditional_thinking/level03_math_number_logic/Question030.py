def main():
    # Question 30: : Check whether a number is a perfect square (without using the square root function).
    number = 49
    perfectSquare = False
    i = 1
    while i * i <= number:
        if i * i == number:
            perfectSquare = True
            break
        i += 1
    print("Perfect square" if perfectSquare else "Not a perfect square")


if __name__ == "__main__":
    main()

"""
Explanation:
The value stored in `perfectSquare` is the input that the conditions or loops work on.
The `for` loop starts with `int i = 1`, keeps running while `i * i <= number` is true, and updates using `i++`.
The condition `i * i == number` decides whether the current value matches the requirement.
The print statement shows each value as soon as that value is calculated inside the loop.
"""
