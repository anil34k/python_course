def main():
    # Question 26: : Take coordinates (x, y) and determine which quadrant the point lies in.
    x = -4
    y = 6
    if x > 0 and y > 0:
        print("Quadrant I")
    elif x < 0 and y > 0:
        print("Quadrant II")
    elif x < 0 and y < 0:
        print("Quadrant III")
    elif x > 0 and y < 0:
        print("Quadrant IV")
    else:
        print("Point lies on an axis or origin")


if __name__ == "__main__":
    main()

"""
Explanation:
The value stored in `x` is the input that the conditions or loops work on.
The if/else checks test the important cases in order: `x > 0 && y > 0`, `x < 0 && y > 0`, `x < 0 && y < 0`.
Only the branch whose condition becomes true prints its message.
"""
