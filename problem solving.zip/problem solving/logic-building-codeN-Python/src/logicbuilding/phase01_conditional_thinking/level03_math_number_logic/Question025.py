def main():
    # Question 25: : Check if a number is a multiple of 7 or ends with 7.
    number = 147
    if number % 7 == 0 or abs(number) % 10 == 7:
        print("Matches condition")
    else:
        print("Does not match condition")


if __name__ == "__main__":
    main()

"""
Explanation:
The value stored in `number` is the input that the conditions or loops work on.
The condition `number % 7 == 0 || Math.abs(number) % 10 == 7` decides whether the current value matches the requirement.
Only the branch whose condition becomes true prints its message.
"""
