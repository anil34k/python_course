def main():
    # Question 28: : Check if a number lies within the range [100, 999].
    number = 456
    if number >= 100 and number <= 999:
        print("Inside range")
    else:
        print("Outside range")


if __name__ == "__main__":
    main()

"""
Explanation:
The value stored in `number` is the input that the conditions or loops work on.
The condition `number >= 100 && number <= 999` decides whether the current value matches the requirement.
Only the branch whose condition becomes true prints its message.
"""
