def main():
    # Question 22: : Take a 3-digit number and determine if the middle digit is the largest, smallest, or neither.
    number = 582
    hundreds = number // 100
    middle = (number // 10) % 10
    ones = number % 10
    if middle > hundreds and middle > ones:
        print("Middle digit is largest")
    elif middle < hundreds and middle < ones:
        print("Middle digit is smallest")
    else:
        print("Middle digit is neither")


if __name__ == "__main__":
    main()

"""
Explanation:
The variables `hundreds`, `middle`, and `ones` hold the values that the logic checks, counts, or transforms.
The if/else checks test the important cases in order: `middle > hundreds && middle > ones`, `middle < hundreds && middle < ones`.
Only the branch whose condition becomes true prints its message.
"""
