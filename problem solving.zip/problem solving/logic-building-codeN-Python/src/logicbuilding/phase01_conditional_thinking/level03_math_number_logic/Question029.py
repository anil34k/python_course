def main():
    # Question 29: : Take two angles of a triangle and compute the third angle.
    firstAngle = 50
    secondAngle = 60
    thirdAngle = 180 - firstAngle - secondAngle
    print("Third angle = " + str(thirdAngle))


if __name__ == "__main__":
    main()

"""
Explanation:
The variables `firstAngle`, `secondAngle`, and `thirdAngle` hold the values that the logic checks, counts, or transforms.
The calculated answer is printed after the logic produces the final value.
"""
