def main():
    # Question 11: : Take three sides and check if they form a valid triangle.
    a = 3
    b = 4
    c = 5
    if a + b > c and a + c > b and b + c > a:
        print("Valid triangle")
    else:
        print("Invalid triangle")


if __name__ == "__main__":
    main()

"""
Explanation:
The value stored in `a` is the input that the conditions or loops work on.
The condition `a + b > c && a + c > b && b + c > a` decides whether the current value matches the requirement.
Only the branch whose condition becomes true prints its message.
"""
