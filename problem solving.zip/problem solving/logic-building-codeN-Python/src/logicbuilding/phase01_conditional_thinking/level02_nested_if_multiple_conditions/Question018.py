def main():
    # Question 18: : Take an alphabet character and check if it lies between 'a' and 'm' or 'n' and 'z'.
    ch = 'h'
    if ch >= 'a' and ch <= 'm':
        print("Between a and m")
    elif ch >= 'n' and ch <= 'z':
        print("Between n and z")
    else:
        print("Not a lowercase alphabet")


if __name__ == "__main__":
    main()

"""
Explanation:
The value stored in `ch` is the input that the conditions or loops work on.
The if/else checks test the important cases in order: `ch >= 'a' && ch <= 'm'`, `ch >= 'n' && ch <= 'z'`.
Only the branch whose condition becomes true prints its message.
"""
