def main():
    # Question 16: : Check voting eligibility for a given age (18+).
    age = 19
    if age >= 18:
        print("Eligible to vote")
    else:
        print("Not eligible to vote")


if __name__ == "__main__":
    main()

"""
Explanation:
The value stored in `age` is the input that the conditions or loops work on.
The condition `age >= 18` decides whether the current value matches the requirement.
Only the branch whose condition becomes true prints its message.
"""
