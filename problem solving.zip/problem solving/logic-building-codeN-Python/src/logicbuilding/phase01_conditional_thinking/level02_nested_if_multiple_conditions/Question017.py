def main():
    # Question 17: : Take two numbers and determine whether both are even, both are odd, or one is even and one is odd.
    first = 12
    second = 18
    if first % 2 == 0 and second % 2 == 0:
        print("Both are even")
    elif first % 2 != 0 and second % 2 != 0:
        print("Both are odd")
    else:
        print("One is even and one is odd")


if __name__ == "__main__":
    main()

"""
Explanation:
The value stored in `first` is the input that the conditions or loops work on.
The if/else checks test the important cases in order: `first % 2 == 0 && second % 2 == 0`, `first % 2 != 0 && second % 2 != 0`.
Only the branch whose condition becomes true prints its message.
"""
