def main():
    # Question 15: : Take the hour of the day (0-23) and print "Good Morning", "Good Afternoon", "Good Evening", or "Good Night".
    hour = 16
    if hour >= 5 and hour < 12:
        print("Good Morning")
    elif hour >= 12 and hour < 17:
        print("Good Afternoon")
    elif hour >= 17 and hour < 21:
        print("Good Evening")
    else:
        print("Good Night")


if __name__ == "__main__":
    main()

"""
Explanation:
The value stored in `hour` is the input that the conditions or loops work on.
The if/else checks test the important cases in order: `hour >= 5 && hour < 12`, `hour >= 12 && hour < 17`, `hour >= 17 && hour < 21`.
Only the branch whose condition becomes true prints its message.
"""
