def main():
    # Question: Take a day number (1-7) and print the corresponding day name.
    day = 3
    days = ["Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday", "Sunday"]
    if 1 <= day <= 7:
        print(days[day - 1])
    else:
        print("Invalid day")


if __name__ == "__main__":
    main()

"""
Explanation:
The value stored in `day` is the input that the conditions or loops work on.
The calculated answer is printed after the logic produces the final value.
"""
