def main():
    # Question 12: : If the sides form a valid triangle, determine whether it is equilateral, isosceles, or scalene.
    a = 5
    b = 5
    c = 8
    if a + b > c and a + c > b and b + c > a:
        if a == b and b == c:
            print("Equilateral")
        elif a == b or b == c or a == c:
            print("Isosceles")
        else:
            print("Scalene")
    else:
        print("Invalid triangle")


if __name__ == "__main__":
    main()

"""
Explanation:
The value stored in `a` is the input that the conditions or loops work on.
The if/else checks test the important cases in order: `a + b > c && a + c > b && b + c > a`, `a == b && b == c`, `a == b || b == c || a == c`.
Only the branch whose condition becomes true prints its message.
"""
