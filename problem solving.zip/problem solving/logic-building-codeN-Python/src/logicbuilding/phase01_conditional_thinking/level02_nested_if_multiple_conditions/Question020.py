def main():
    # Question 20: : Take a month number (1-12) and print the number of days in that month (ignore leap years).
    year = 2024
    if (year % 400 == 0) or (year % 4 == 0 and year % 100 != 0):
        print("Leap year")
    else:
        print("Not a leap year")


if __name__ == "__main__":
    main()

"""
Explanation:
The value stored in `year` is the input that the conditions or loops work on.
The condition `(year % 400 == 0) || (year % 4 == 0 && year % 100 != 0)` decides whether the current value matches the requirement.
Only the branch whose condition becomes true prints its message.
"""
