def main():
    # Question 13: : Take marks (0-100) and print the corresponding grade (A/B/C/D/F).
    marks = 82
    if marks >= 90:
        print("A")
    elif marks >= 75:
        print("B")
    elif marks >= 60:
        print("C")
    elif marks >= 40:
        print("D")
    else:
        print("F")


if __name__ == "__main__":
    main()

"""
Explanation:
The value stored in `marks` is the input that the conditions or loops work on.
The if/else checks test the important cases in order: `marks >= 90`, `marks >= 75`, `marks >= 60`.
Only the branch whose condition becomes true prints its message.
"""
