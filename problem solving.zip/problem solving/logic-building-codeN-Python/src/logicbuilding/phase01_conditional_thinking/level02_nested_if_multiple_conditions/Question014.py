def main():
    # Question 14: : Check if one of two given numbers is a multiple of the other.
    first = 12
    second = 36
    if first != 0 and second % first == 0:
        print("Second is a multiple of first")
    elif second != 0 and first % second == 0:
        print("First is a multiple of second")
    else:
        print("No number is a multiple of the other")


if __name__ == "__main__":
    main()

"""
Explanation:
The value stored in `first` is the input that the conditions or loops work on.
The if/else checks test the important cases in order: `first != 0 && second % first == 0`, `second != 0 && first % second == 0`.
Only the branch whose condition becomes true prints its message.
"""
