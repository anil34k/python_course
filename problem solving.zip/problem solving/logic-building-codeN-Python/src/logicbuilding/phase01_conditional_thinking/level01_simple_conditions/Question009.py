def isVowel(ch):
    lower = ch.lower()
    return lower == 'a' or lower == 'e' or lower == 'i' or lower == 'o' or lower == 'u'

def main():
    # Question 9: : Take a character and check if it's a vowel or consonant.
    ch = 'e'
    if ch.isalpha():
        if isVowel(ch):
            print("Vowel")
        else:
            print("Consonant")
    else:
        print("Not an alphabet")


if __name__ == "__main__":
    main()

"""
Explanation:
The value stored in `ch` is the input that the conditions or loops work on.
The helper checks characters against `a`, `e`, `i`, `o`, and `u`, so the main loop only needs to use that true/false result.
The if/else checks test the important cases in order: `Character.isLetter(ch)`, `isVowel(ch)`.
Only the branch whose condition becomes true prints its message.
"""
