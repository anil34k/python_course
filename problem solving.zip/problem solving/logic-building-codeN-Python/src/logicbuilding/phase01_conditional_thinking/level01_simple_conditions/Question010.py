def main():
    # Question 10: : Take a character and check whether it's uppercase, lowercase, a digit, or a special character.
    ch = 'A'
    if ch.isupper():
        print("Uppercase")
    elif ch.islower():
        print("Lowercase")
    elif ch.isdigit():
        print("Digit")
    else:
        print("Special character")


if __name__ == "__main__":
    main()

"""
Explanation:
The value stored in `ch` is the input that the conditions or loops work on.
The if/else checks test the important cases in order: `Character.isUpperCase(ch)`, `Character.isLowerCase(ch)`, `Character.isDigit(ch)`.
Only the branch whose condition becomes true prints its message.
"""
