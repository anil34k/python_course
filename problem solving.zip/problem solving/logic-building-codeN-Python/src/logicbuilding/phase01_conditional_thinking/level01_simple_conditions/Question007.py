def main():
    # Question 7: : Take three numbers and print the largest.
    first = 20
    second = 35
    third = 12
    largest = first
    if second > largest:
        largest = second
    if third > largest:
        largest = third
    print("Largest = " + str(largest))


if __name__ == "__main__":
    main()

"""
Explanation:
The variables `first`, and `largest` hold the values that the logic checks, counts, or transforms.
The if/else checks test the important cases in order: `second > largest`, `third > largest`.
Only the branch whose condition becomes true prints its message.
"""
