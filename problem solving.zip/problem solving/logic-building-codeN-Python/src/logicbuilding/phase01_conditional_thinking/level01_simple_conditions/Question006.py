def main():
    # Question 6: : Take two numbers and print the larger one.
    first = 20
    second = 35
    if first > second:
        print(first)
    else:
        print(second)


if __name__ == "__main__":
    main()

"""
Explanation:
The variables `first`, and `second` hold the values that the logic checks, counts, or transforms.
The condition `first > second` decides whether the current value matches the requirement.
Only the branch whose condition becomes true prints its message.
"""
