def main():
    # Question 2: : Check if a number is even or odd.
    number = 18
    if number % 2 == 0:
        print("Even")
    else:
        print("Odd")


if __name__ == "__main__":
    main()

"""
Explanation:
The value stored in `number` is the input that the conditions or loops work on.
The condition `number % 2 == 0` decides whether the current value matches the requirement.
Only the branch whose condition becomes true prints its message.
"""
