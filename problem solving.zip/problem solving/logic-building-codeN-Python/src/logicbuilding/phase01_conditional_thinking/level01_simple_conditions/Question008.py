def main():
    # Question 8: : Take a temperature value and print "Cold", "Warm", or "Hot" using range conditions.
    temperature = 31
    if temperature < 15:
        print("Cold")
    elif temperature <= 30:
        print("Warm")
    else:
        print("Hot")


if __name__ == "__main__":
    main()

"""
Explanation:
The value stored in `temperature` is the input that the conditions or loops work on.
The if/else checks test the important cases in order: `temperature < 15`, `temperature <= 30`.
Only the branch whose condition becomes true prints its message.
"""
