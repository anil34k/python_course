def isVowel(ch):
    lower = ch.lower()
    return lower == 'a' or lower == 'e' or lower == 'i' or lower == 'o' or lower == 'u'

def main():
    # Question 11: : Count how many vowels and consonants are in a string.
    text = "logic"
    vowels = 0
    consonants = 0
    for i in range(0, len(text)):
        ch = text[i]
        if ch.isalpha():
            if isVowel(ch):
                vowels += 1
            else:
                consonants += 1
    print("Vowels = " + str(vowels) + ", Consonants = " + str(consonants))


if __name__ == "__main__":
    main()

"""
Explanation:
The variables `text`, `vowels`, and `ch` hold the values that the logic checks, counts, or transforms.
The helper checks characters against `a`, `e`, `i`, `o`, and `u`, so the main loop only needs to use that true/false result.
The `for` loop starts with `int i = 0`, keeps running while `i < text.length()` is true, and updates using `i++`.
`charAt(i)` lets the code inspect one character at a time by index.
The if/else checks test the important cases in order: `Character.isLetter(ch)`, `isVowel(ch)`.
The print statement shows each value as soon as that value is calculated inside the loop.
"""
