def main():
    # Question 14: : Find the frequency of each character in a string (without using a map).
    text = "banana"
    visited = [False] * (len(text))
    for i in range(0, len(text)):
        if visited[i]:
            continue
        count = 1
        for j in range(i + 1, len(text)):
            if text[i] == text[j]:
                visited[j] = True
                count += 1
        print(str(text[i]) + " -> " + str(count))


if __name__ == "__main__":
    main()

"""
Explanation:
The variables `text`, and `visited` hold the values that the logic checks, counts, or transforms.
The `for` loop starts with `int i = 0`, keeps running while `i < text.length()` is true, and updates using `i++`.
`charAt(i)` lets the code inspect one character at a time by index.
The condition `text.charAt(i) == text.charAt(j)` decides whether the current value matches the requirement.
The print statement shows each value as soon as that value is calculated inside the loop.
"""
