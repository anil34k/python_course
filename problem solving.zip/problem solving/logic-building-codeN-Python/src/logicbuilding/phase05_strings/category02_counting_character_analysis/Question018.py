def main():
    # Question 18: : Count how many substrings start and end with the same character (simple logic).
    text = "abca"
    count = 0
    for start in range(0, len(text)):
        for end in range(start, len(text)):
            if text[start] == text[end]:
                count += 1
    print("Count = " + str(count))


if __name__ == "__main__":
    main()

"""
Explanation:
The variables `text`, `start`, and `end` hold the values that the logic checks, counts, or transforms.
The `for` loop starts with `int start = 0`, keeps running while `start < text.length()` is true, and updates using `start++`.
The variable `count` starts at 0 and increases only when the current item satisfies the question's condition.
`charAt(i)` lets the code inspect one character at a time by index.
The condition `text.charAt(start) == text.charAt(end)` decides whether the current value matches the requirement.
The print statement shows each value as soon as that value is calculated inside the loop.
"""
