def main():
    # Question 13: : Count how many uppercase and lowercase letters a string has.
    text = "CodeN"
    upper = 0
    lower = 0
    for i in range(0, len(text)):
        ch = text[i]
        if ch.isupper():
            upper += 1
        elif ch.islower():
            lower += 1
    print("Uppercase = " + str(upper) + ", Lowercase = " + str(lower))


if __name__ == "__main__":
    main()

"""
Explanation:
The variables `text`, `upper`, and `ch` hold the values that the logic checks, counts, or transforms.
The `for` loop starts with `int i = 0`, keeps running while `i < text.length()` is true, and updates using `i++`.
`charAt(i)` lets the code inspect one character at a time by index.
The if/else checks test the important cases in order: `Character.isUpperCase(ch)`, `Character.isLowerCase(ch)`.
The print statement shows each value as soon as that value is calculated inside the loop.
"""
