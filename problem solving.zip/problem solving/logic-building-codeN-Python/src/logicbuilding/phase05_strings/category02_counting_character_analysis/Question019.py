def isVowel(ch):
    lower = ch.lower()
    return lower == 'a' or lower == 'e' or lower == 'i' or lower == 'o' or lower == 'u'

def main():
    # Question 19: : Print how many words start with a vowel in a sentence.
    sentence = "apple code is easy"
    count = 0
    for word in sentence.split():
        if not word == "" and isVowel(word[0]):
            count += 1
    print("Count = " + str(count))


if __name__ == "__main__":
    main()

"""
Explanation:
The value stored in `sentence` is the input that the conditions or loops work on.
The helper checks characters against `a`, `e`, `i`, `o`, and `u`, so the main loop only needs to use that true/false result.
The loop goes word by word after splitting the sentence, so each word can be checked separately.
The variable `count` starts at 0 and increases only when the current item satisfies the question's condition.
`split("\\s+")` breaks the sentence wherever spaces appear, giving us separate words to process.
The condition `!word.isEmpty() && isVowel(word.charAt(0))` decides whether the current value matches the requirement.
"""
