def main():
    # Question 17: : Count how many alphabets are before 'm' and after 'm' in a given string.
    text = "alphabet"
    before = 0
    after = 0
    for i in range(0, len(text)):
        ch = text[i].lower()
        if ch >= 'a' and ch < 'm':
            before += 1
        elif ch > 'm' and ch <= 'z':
            after += 1
    print("Before m = " + str(before) + ", After m = " + str(after))


if __name__ == "__main__":
    main()

"""
Explanation:
The variables `text`, `before`, and `ch` hold the values that the logic checks, counts, or transforms.
The `for` loop starts with `int i = 0`, keeps running while `i < text.length()` is true, and updates using `i++`.
`charAt(i)` lets the code inspect one character at a time by index.
The if/else checks test the important cases in order: `ch >= 'a' && ch < 'm'`, `ch > 'm' && ch <= 'z'`.
The print statement shows each value as soon as that value is calculated inside the loop.
"""
