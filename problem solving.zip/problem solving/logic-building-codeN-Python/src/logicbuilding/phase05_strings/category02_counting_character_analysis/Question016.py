def main():
    # Question 16: : Count how many times a given character appears in a string.
    text = "banana"
    target = 'a'
    count = 0
    for i in range(0, len(text)):
        if text[i] == target:
            count += 1
    print("Count = " + str(count))


if __name__ == "__main__":
    main()

"""
Explanation:
The variables `text`, and `target` hold the values that the logic checks, counts, or transforms.
The `for` loop starts with `int i = 0`, keeps running while `i < text.length()` is true, and updates using `i++`.
The variable `count` starts at 0 and increases only when the current item satisfies the question's condition.
`charAt(i)` lets the code inspect one character at a time by index.
The condition `text.charAt(i) == target` decides whether the current value matches the requirement.
The print statement shows each value as soon as that value is calculated inside the loop.
"""
