def main():
    # Question 50: : Remove extra spaces between words (normalize spacing).
    sentence = "logic   building   is   fun"
    print(str(sentence.strip().replaceAll("\\s+", " ")))


if __name__ == "__main__":
    main()

"""
Explanation:
The value stored in `sentence` is the input that the conditions or loops work on.
The calculated answer is printed after the logic produces the final value.
"""
