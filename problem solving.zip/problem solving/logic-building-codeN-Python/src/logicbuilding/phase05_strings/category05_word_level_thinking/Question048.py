def main():
    # Question 48: : Capitalize the first letter of each word.
    sentence = "logic building is fun"
    result = ""
    for word in sentence.split():
        result += str(word[0].upper()).append(word.substring(1).lower()).append(" ")
    print(result.toString().strip())


if __name__ == "__main__":
    main()

"""
Explanation:
The value stored in `sentence` is the input that the conditions or loops work on.
The loop goes word by word after splitting the sentence, so each word can be checked separately.
A `StringBuilder` is used so characters or words can be added gradually while building the final string.
`split("\\s+")` breaks the sentence wherever spaces appear, giving us separate words to process.
The print statement shows each value as soon as that value is calculated inside the loop.
"""
