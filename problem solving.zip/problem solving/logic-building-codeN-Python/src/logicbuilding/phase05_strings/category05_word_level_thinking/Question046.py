def main():
    # Question: Print words whose first and last characters are the same.
    sentence = "area code civic"
    for word in sentence.split():
        if word[0] == word[-1]:
            print(word)


if __name__ == "__main__":
    main()

"""
Explanation:
The value stored in `sentence` is the input that the conditions or loops work on.
The loop goes word by word after splitting the sentence, so each word can be checked separately.
`split("\\s+")` breaks the sentence wherever spaces appear, giving us separate words to process.
The condition `word.charAt(0) == word.charAt(word.length() - 1)` decides whether the current value matches the requirement.
The print statement shows each value as soon as that value is calculated inside the loop.
"""
