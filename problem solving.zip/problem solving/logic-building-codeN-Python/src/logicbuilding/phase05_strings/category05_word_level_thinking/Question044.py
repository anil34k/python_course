def main():
    # Question 44: : Find the shortest word in a sentence.
    sentence = "logic building is fun"
    best = sentence.split()[0]
    for word in sentence.split():
        if len(word) < len(best):
            best = word
    print(best)


if __name__ == "__main__":
    main()

"""
Explanation:
The variables `sentence`, and `best` hold the values that the logic checks, counts, or transforms.
The loop goes word by word after splitting the sentence, so each word can be checked separately.
`split("\\s+")` breaks the sentence wherever spaces appear, giving us separate words to process.
The condition `word.length() < best.length()` decides whether the current value matches the requirement.
The print statement shows each value as soon as that value is calculated inside the loop.
"""
