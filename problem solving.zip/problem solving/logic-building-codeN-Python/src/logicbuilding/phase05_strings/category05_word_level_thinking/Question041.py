def main():
    # Question 41: : Print each word of a sentence on a new line.
    sentence = "logic building is fun"
    for word in sentence.split():
        print(word)


if __name__ == "__main__":
    main()

"""
Explanation:
The value stored in `sentence` is the input that the conditions or loops work on.
The loop goes word by word after splitting the sentence, so each word can be checked separately.
`split("\\s+")` breaks the sentence wherever spaces appear, giving us separate words to process.
The print statement shows each value as soon as that value is calculated inside the loop.
"""
