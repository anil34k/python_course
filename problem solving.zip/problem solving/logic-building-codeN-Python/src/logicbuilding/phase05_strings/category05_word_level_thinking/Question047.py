def main():
    # Question 47: : Count how many words contain the letter 'a'.
    sentence = "java logic arrays"
    count = 0
    for word in sentence.split():
        if word.find('a') >= 0:
            count += 1
    print("Count = " + str(count))


if __name__ == "__main__":
    main()

"""
Explanation:
The value stored in `sentence` is the input that the conditions or loops work on.
The loop goes word by word after splitting the sentence, so each word can be checked separately.
The variable `count` starts at 0 and increases only when the current item satisfies the question's condition.
`split("\\s+")` breaks the sentence wherever spaces appear, giving us separate words to process.
The condition `word.indexOf('a') >= 0` decides whether the current value matches the requirement.
The print statement shows each value as soon as that value is calculated inside the loop.
"""
