def main():
    # Question 45: : Swap first and last words in a sentence.
    words = "logic building is fun".split()
    temp = words[0]
    words[0] = words[len(words) - 1]
    words[len(words) - 1] = temp
    for word in words:
        print(str(word) + " ", end="")
    print()


if __name__ == "__main__":
    main()

"""
Explanation:
The variables `temp`, and `words` hold the values that the logic checks, counts, or transforms.
The loop goes word by word after splitting the sentence, so each word can be checked separately.
`split("\\s+")` breaks the sentence wherever spaces appear, giving us separate words to process.
`System.out.println()` is used only to move to the next line after the pattern output is complete.
"""
