def main():
    # Question 39: : Swap case: uppercase -> lowercase and lowercase -> uppercase.
    text = "Java Logic"
    result = ""

    for i in range(0, len(text)):
        ch = text[i]
        if ch.isupper():
            result += str(ch.lower())
        elif ch.islower():
            result += str(ch.upper())
        else:
            result += str(ch)

    print(result)


if __name__ == "__main__":
    main()

"""
Explanation:
The variables `text`, and `ch` hold the values that the logic checks, counts, or transforms.
The `for` loop starts with `int i = 0`, keeps running while `i < text.length()` is true, and updates using `i++`.
A `StringBuilder` is used so characters or words can be added gradually while building the final string.
`charAt(i)` lets the code inspect one character at a time by index.
The if/else checks test the important cases in order: `Character.isUpperCase(ch)`, `Character.isLowerCase(ch)`.
The print statement shows each value as soon as that value is calculated inside the loop.
"""
