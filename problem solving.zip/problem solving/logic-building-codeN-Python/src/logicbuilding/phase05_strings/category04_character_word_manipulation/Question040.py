def main():
    # Question: Replace every character by its next character.
    text = "abc"
    result = ""
    for ch in text:
        result += chr(ord(ch) + 1)
    print(result)


if __name__ == "__main__":
    main()

"""
Explanation:
The value stored in `text` is the input that the conditions or loops work on.
The `for` loop starts with `int i = 0`, keeps running while `i < text.length()` is true, and updates using `i++`.
A `StringBuilder` is used so characters or words can be added gradually while building the final string.
`charAt(i)` lets the code inspect one character at a time by index.
The print statement shows each value as soon as that value is calculated inside the loop.
"""
