def main():
    # Question 32: : Remove all spaces from a string.
    text = "logic building"
    print(str(text.replace(" ", "")))


if __name__ == "__main__":
    main()

"""
Explanation:
The value stored in `text` is the input that the conditions or loops work on.
The calculated answer is printed after the logic produces the final value.
"""
