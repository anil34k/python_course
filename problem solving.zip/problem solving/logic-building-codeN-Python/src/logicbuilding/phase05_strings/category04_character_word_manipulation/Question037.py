def main():
    # Question 37: : Keep only the first occurrence of each character.
    text = "banana"
    result = ""
    for i in range(0, len(text)):
        ch = text[i]
        if result.find(String.valueOf(ch)) == -1:
            result += str(ch)
    print(result)


if __name__ == "__main__":
    main()

"""
Explanation:
The variables `text`, and `ch` hold the values that the logic checks, counts, or transforms.
The `for` loop starts with `int i = 0`, keeps running while `i < text.length()` is true, and updates using `i++`.
A `StringBuilder` is used so characters or words can be added gradually while building the final string.
`charAt(i)` lets the code inspect one character at a time by index.
The print statement shows each value as soon as that value is calculated inside the loop.
"""
