def main():
    # Question 30: : Reverse string but skip spaces.
    text = "logic building is fun"
    spaces = 0
    for i in range(0, len(text)):
        if text[i] == ' ':
            spaces += 1
    print("Spaces = " + str(spaces))


if __name__ == "__main__":
    main()

"""
Explanation:
The variables `text`, and `spaces` hold the values that the logic checks, counts, or transforms.
The `for` loop starts with `int i = 0`, keeps running while `i < text.length()` is true, and updates using `i++`.
`charAt(i)` lets the code inspect one character at a time by index.
The condition `text.charAt(i) == ' '` decides whether the current value matches the requirement.
The print statement shows each value as soon as that value is calculated inside the loop.
"""
