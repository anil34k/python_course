def reverse_string(text):
    return text[::-1]

def main():
    # Question: Reverse each word in a sentence.
    sentence = "logic building is fun"
    for word in sentence.split():
        print(reverse_string(word), end=" ")
    print()


if __name__ == "__main__":
    main()

"""
Explanation:
The value stored in `sentence` is the input that the conditions or loops work on.
The helper builds the answer from the last digit or last character toward the first one.
The loop goes word by word after splitting the sentence, so each word can be checked separately.
`split("\\s+")` breaks the sentence wherever spaces appear, giving us separate words to process.
`System.out.println()` is used only to move to the next line after the pattern output is complete.
"""
