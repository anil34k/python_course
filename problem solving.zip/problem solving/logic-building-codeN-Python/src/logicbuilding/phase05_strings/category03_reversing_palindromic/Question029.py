def main():
    # Question: Reverse only the digits in a string.
    text = "a1b2c3"
    digits = [ch for ch in text if ch.isdigit()]
    result = ""
    for ch in text:
        result += digits.pop() if ch.isdigit() else ch
    print(result)


if __name__ == "__main__":
    main()

"""
Explanation:
The variables `text`, `left`, `temp`, and `chars` hold the values that the logic checks, counts, or transforms.
The `while` or `do-while` loop keeps repeating until the changing value reaches the stopping condition.
The if/else checks test the important cases in order: `Character.isDigit(chars[left])`, `Character.isDigit(chars[right])`.
Only the branch whose condition becomes true prints its message.
"""
