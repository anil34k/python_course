def reverseString(text):
    builder = ""
    for i in range(len(text) - 1, 0 - 1, -1):
        builder += str(text[i])
    return builder.toString()

def main():
    # Question 21: : Reverse a string without using built-in reverse.
    text = "logic"
    print(reverseString(text))


if __name__ == "__main__":
    main()

"""
Explanation:
The value stored in `text` is the input that the conditions or loops work on.
The helper builds the answer from the last digit or last character toward the first one.
The calculated answer is printed after the logic produces the final value.
"""
