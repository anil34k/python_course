def reverseString(text):
    builder = ""
    for i in range(len(text) - 1, 0 - 1, -1):
        builder += str(text[i])
    return builder.toString()

def main():
    # Question 25: : Check if two strings are the reverse of each other.
    first = "abc"
    second = "cba"
    print("Reverse of each other" if reverseString(first).equals(second) else "Not reverse of each other")


if __name__ == "__main__":
    main()

"""
Explanation:
The variables `first`, and `second` hold the values that the logic checks, counts, or transforms.
The helper builds the answer from the last digit or last character toward the first one.
The calculated answer is printed after the logic produces the final value.
"""
