def main():
    # Question 26: : Print the middle character(s) of a string.
    text = "coding"
    length = len(text)
    if length % 2 == 0:
        print(text.substring(length / 2 - 1, length / 2 + 1))
    else:
        print(text[length / 2])


if __name__ == "__main__":
    main()

"""
Explanation:
The variables `text`, and `length` hold the values that the logic checks, counts, or transforms.
`charAt(i)` lets the code inspect one character at a time by index.
The condition `length % 2 == 0` decides whether the current value matches the requirement.
Only the branch whose condition becomes true prints its message.
"""
