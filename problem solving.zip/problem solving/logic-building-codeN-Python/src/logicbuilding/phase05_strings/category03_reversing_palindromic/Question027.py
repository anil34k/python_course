def reverseString(text):
    builder = ""
    for i in range(len(text) - 1, 0 - 1, -1):
        builder += str(text[i])
    return builder.toString()

def main():
    # Question 27: : Print the second half of the string in reverse.
    text = "logicbuild"
    secondHalf = text.substring(len(text) / 2)
    print(reverseString(secondHalf))


if __name__ == "__main__":
    main()

"""
Explanation:
The variables `text`, and `secondHalf` hold the values that the logic checks, counts, or transforms.
The helper builds the answer from the last digit or last character toward the first one.
The calculated answer is printed after the logic produces the final value.
"""
