def main():
    # Question 23: : Reverse the order of words in a sentence.
    words = "logic building is fun".split()
    for i in range(len(words) - 1, 0 - 1, -1):
        print(str(words[i]) + " ", end="")
    print()


if __name__ == "__main__":
    main()

"""
Explanation:
The value stored in `words` is the input that the conditions or loops work on.
The `for` loop starts with `int i = words.length - 1`, keeps running while `i >= 0` is true, and updates using `i--`.
`split("\\s+")` breaks the sentence wherever spaces appear, giving us separate words to process.
`System.out.println()` is used only to move to the next line after the pattern output is complete.
"""
