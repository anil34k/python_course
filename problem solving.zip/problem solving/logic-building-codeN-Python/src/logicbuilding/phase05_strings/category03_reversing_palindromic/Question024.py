def isPalindromeString(text):
    cleaned = text.replace(" ", "").lower()
    left = 0
    right = len(cleaned) - 1
    while left < right:
        if cleaned[left] != cleaned[right]:
            return False
        left += 1
        right -= 1
    return True

def main():
    # Question 24: : Check whether a string is a palindrome.
    text = "level"
    print("Palindrome" if isPalindromeString(text) else "Not palindrome")


if __name__ == "__main__":
    main()

"""
Explanation:
The value stored in `text` is the input that the conditions or loops work on.
The helper compares the original value with its reversed form, because a palindrome reads the same both ways.
The calculated answer is printed after the logic produces the final value.
"""
