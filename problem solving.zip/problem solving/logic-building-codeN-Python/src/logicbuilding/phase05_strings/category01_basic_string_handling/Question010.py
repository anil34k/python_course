def main():
    # Question 10: : Check whether the string is empty or not.
    text = ""
    print("Empty" if text == "" else "Not empty")


if __name__ == "__main__":
    main()

"""
Explanation:
The value stored in `text` is the input that the conditions or loops work on.
The calculated answer is printed after the logic produces the final value.
"""
