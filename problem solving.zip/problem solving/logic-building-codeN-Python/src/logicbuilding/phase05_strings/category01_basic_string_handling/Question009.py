def main():
    # Question: Print ASCII value of each character.
    text = "Code"
    for ch in text:
        print(ch + " = " + str(ord(ch)))


if __name__ == "__main__":
    main()

"""
Explanation:
The value stored in `text` is the input that the conditions or loops work on.
The `for` loop starts with `int i = 0`, keeps running while `i < text.length()` is true, and updates using `i++`.
`charAt(i)` lets the code inspect one character at a time by index.
The print statement shows each value as soon as that value is calculated inside the loop.
"""
