def main():
    # Question 6: : Count how many words are in a sentence.
    sentence = "logic building is fun"
    words = sentence.strip().split()
    print("Words = " + str(len(words)))


if __name__ == "__main__":
    main()

"""
Explanation:
The variables `sentence`, and `words` hold the values that the logic checks, counts, or transforms.
`split("\\s+")` breaks the sentence wherever spaces appear, giving us separate words to process.
The calculated answer is printed after the logic produces the final value.
"""
