def main():
    # Question 8: : Compare two strings lexicographically (like dictionary order).
    first = "apple"
    second = "banana"
    result = first.compareTo(second)
    print("First comes earlier" if result < 0 else "Second comes earlier" if result > 0 else "Both are equal")


if __name__ == "__main__":
    main()

"""
Explanation:
The variables `first`, and `second` hold the values that the logic checks, counts, or transforms.
The calculated answer is printed after the logic produces the final value.
"""
