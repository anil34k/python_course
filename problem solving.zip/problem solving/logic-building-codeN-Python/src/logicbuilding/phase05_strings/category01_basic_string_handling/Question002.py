def main():
    # Question: Print the last character of a string.
    text = "logic"
    print("Last = " + text[-1])


if __name__ == "__main__":
    main()

"""
Explanation:
The value stored in `text` is the input that the conditions or loops work on.
`charAt(i)` lets the code inspect one character at a time by index.
The calculated answer is printed after the logic produces the final value.
"""
