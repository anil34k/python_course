def main():
    # Question 4: : Convert all characters of a string to lowercase.
    text = "LOGIC"
    print(text.lower())


if __name__ == "__main__":
    main()

"""
Explanation:
The value stored in `text` is the input that the conditions or loops work on.
The calculated answer is printed after the logic produces the final value.
"""
