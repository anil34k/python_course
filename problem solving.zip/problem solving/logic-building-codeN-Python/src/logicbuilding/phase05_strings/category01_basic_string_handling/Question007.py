def main():
    # Question 7: : Take two strings and print them concatenated.
    first = "Code"
    second = "Nishchal"
    print(first + second)


if __name__ == "__main__":
    main()

"""
Explanation:
The variables `first`, and `second` hold the values that the logic checks, counts, or transforms.
The calculated answer is printed after the logic produces the final value.
"""
