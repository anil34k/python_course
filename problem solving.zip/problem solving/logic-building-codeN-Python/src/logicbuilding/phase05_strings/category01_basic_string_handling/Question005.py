def main():
    # Question 5: : Count how many characters (excluding spaces) are in the string.
    text = "logic building"
    count = 0
    for i in range(0, len(text)):
        if text[i] != ' ':
            count += 1
    print("Characters = " + str(count))


if __name__ == "__main__":
    main()

"""
Explanation:
The value stored in `text` is the input that the conditions or loops work on.
The `for` loop starts with `int i = 0`, keeps running while `i < text.length()` is true, and updates using `i++`.
The variable `count` starts at 0 and increases only when the current item satisfies the question's condition.
`charAt(i)` lets the code inspect one character at a time by index.
The condition `text.charAt(i) != ' '` decides whether the current value matches the requirement.
The print statement shows each value as soon as that value is calculated inside the loop.
"""
