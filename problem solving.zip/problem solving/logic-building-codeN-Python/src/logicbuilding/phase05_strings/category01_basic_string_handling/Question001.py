def main():
    # Question 1: : Take a string input and print its length.
    text = "CodeWithNishchal"
    print("Length = " + str(len(text)))


if __name__ == "__main__":
    main()

"""
Explanation:
The value stored in `text` is the input that the conditions or loops work on.
The calculated answer is printed after the logic produces the final value.
"""
