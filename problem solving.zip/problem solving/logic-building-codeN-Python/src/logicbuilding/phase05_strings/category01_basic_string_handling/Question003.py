def main():
    # Question 3: : Convert all characters of a string to uppercase.
    text = "logic"
    print(text.upper())


if __name__ == "__main__":
    main()

"""
Explanation:
The value stored in `text` is the input that the conditions or loops work on.
The calculated answer is printed after the logic produces the final value.
"""
