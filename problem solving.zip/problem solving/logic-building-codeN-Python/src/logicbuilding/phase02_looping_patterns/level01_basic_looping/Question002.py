def main():
    # Question 2: : Print all even numbers between 1 and 100.
    for number in range(1, 100 + 1):
        if number % 2 == 0:
            print(number)


if __name__ == "__main__":
    main()

"""
Explanation:
The value stored in `number` is the input that the conditions or loops work on.
The `for` loop starts with `int number = 1`, keeps running while `number <= 100` is true, and updates using `number++`.
The condition `number % 2 == 0` decides whether the current value matches the requirement.
The print statement shows each value as soon as that value is calculated inside the loop.
"""
