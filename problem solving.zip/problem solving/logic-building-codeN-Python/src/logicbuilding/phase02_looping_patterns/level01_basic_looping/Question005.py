def main():
    # Question 5: : Print the table of a given number (n x 1 to n x 10).
    n = 7
    for multiplier in range(1, 10 + 1):
        print(str(n) + " x " + str(multiplier) + " = " + str((n * multiplier)))


if __name__ == "__main__":
    main()

"""
Explanation:
The variables `n`, and `multiplier` hold the values that the logic checks, counts, or transforms.
The `for` loop starts with `int multiplier = 1`, keeps running while `multiplier <= 10` is true, and updates using `multiplier++`.
The print statement shows each value as soon as that value is calculated inside the loop.
"""
