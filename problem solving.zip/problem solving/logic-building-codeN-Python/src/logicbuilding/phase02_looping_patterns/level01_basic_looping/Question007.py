def main():
    # Question 7: : Print the sum of all even numbers up to n.
    n = 20
    sum = 0
    for number in range(1, n + 1):
        if number % 2 == 0:
            sum += number
    print("Even sum = " + str(sum))


if __name__ == "__main__":
    main()

"""
Explanation:
The value stored in `n` is the input that the conditions or loops work on.
The `for` loop starts with `int number = 1`, keeps running while `number <= n` is true, and updates using `number++`.
The variable `sum` starts at 0 and collects values as the loop finds numbers that should be included.
The print statement shows each value as soon as that value is calculated inside the loop.
"""
