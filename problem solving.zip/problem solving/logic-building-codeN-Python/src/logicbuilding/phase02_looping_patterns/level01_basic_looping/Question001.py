def main():
    # Question 1: : Print numbers from 1 to 10.
    for number in range(1, 10 + 1):
        print(number)


if __name__ == "__main__":
    main()

"""
Explanation:
The value stored in `number` is the input that the conditions or loops work on.
The `for` loop starts with `int number = 1`, keeps running while `number <= 10` is true, and updates using `number++`.
The print statement shows each value as soon as that value is calculated inside the loop.
"""
