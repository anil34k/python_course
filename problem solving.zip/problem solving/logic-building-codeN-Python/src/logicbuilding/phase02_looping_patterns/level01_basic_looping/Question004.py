def main():
    # Question 4: : Print numbers from 10 down to 1.
    for number in range(10, 1 - 1, -1):
        print(number)


if __name__ == "__main__":
    main()

"""
Explanation:
The value stored in `number` is the input that the conditions or loops work on.
The `for` loop starts with `int number = 10`, keeps running while `number >= 1` is true, and updates using `number--`.
The print statement shows each value as soon as that value is calculated inside the loop.
"""
