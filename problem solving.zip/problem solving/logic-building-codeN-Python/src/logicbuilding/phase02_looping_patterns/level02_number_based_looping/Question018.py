def isPrime(number):
    if number <= 1:
        return False
    divisor = 2
    while divisor * divisor <= number:
        if number % divisor == 0:
            return False
        divisor += 1
    return True

def main():
    # Question 18: : Check if a number is prime or not.
    number = 29
    print("Prime" if isPrime(number) else "Not prime")


if __name__ == "__main__":
    main()

"""
Explanation:
The value stored in `number` is the input that the conditions or loops work on.
The helper tries possible divisors from 2 up to the square root of the number.
If any divisor divides the number exactly, the number is not prime; otherwise it is prime.
The calculated answer is printed after the logic produces the final value.
"""
