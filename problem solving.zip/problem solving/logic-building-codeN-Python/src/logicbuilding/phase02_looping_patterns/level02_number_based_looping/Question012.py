def reverseNumber(number):
    value = abs(number)
    reversed = 0
    while True:
        reversed = reversed * 10 + value % 10
        value //= 10
        if not (value > 0):
            break
    return -reversed if number < 0 else reversed

def main():
    # Question 12: : Print the reverse of a given number.
    number = 12345
    print("Reverse = " + str(reverseNumber(number)))


if __name__ == "__main__":
    main()

"""
Explanation:
The value stored in `number` is the input that the conditions or loops work on.
The helper builds the answer from the last digit or last character toward the first one.
The calculated answer is printed after the logic produces the final value.
"""
