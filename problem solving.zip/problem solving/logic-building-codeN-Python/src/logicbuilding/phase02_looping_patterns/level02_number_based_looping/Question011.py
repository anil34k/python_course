def main():
    # Question 11: : Count the number of digits in a given number.
    number = 98765
    value = abs(number)
    count = 0
    while True:
        count += 1
        value //= 10
        if not (value > 0):
            break
    print("Digits = " + str(count))


if __name__ == "__main__":
    main()

"""
Explanation:
The variables `number`, `value`, and `count` hold the values that the logic checks, counts, or transforms.
The `while` or `do-while` loop keeps repeating until the changing value reaches the stopping condition.
The variable `count` starts at 0 and increases only when the current item satisfies the question's condition.
The calculated answer is printed after the logic produces the final value.
"""
