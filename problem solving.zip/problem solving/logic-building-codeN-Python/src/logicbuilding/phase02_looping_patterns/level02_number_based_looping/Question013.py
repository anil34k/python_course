def reverseNumber(number):
    value = abs(number)
    reversed = 0
    while True:
        reversed = reversed * 10 + value % 10
        value //= 10
        if not (value > 0):
            break
    return -reversed if number < 0 else reversed

def isPalindromeNumber(number):
    return abs(number) == abs(reverseNumber(number))

def main():
    # Question 13: : Check if a number is a palindrome.
    number = 12321
    print("Palindrome" if isPalindromeNumber(number) else "Not palindrome")


if __name__ == "__main__":
    main()

"""
Explanation:
The value stored in `number` is the input that the conditions or loops work on.
The helper compares the original value with its reversed form, because a palindrome reads the same both ways.
The calculated answer is printed after the logic produces the final value.
"""
