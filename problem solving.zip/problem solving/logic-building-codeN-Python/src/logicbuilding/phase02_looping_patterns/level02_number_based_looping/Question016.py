def isPerfect(number):
    if number <= 1:
        return False
    sum = 1
    for factor in range(2, number / 2 + 1):
        if number % factor == 0:
            sum += factor
    return sum == number

def main():
    # Question 16: : Check if a number is a perfect number.
    number = 28
    print("Perfect number" if isPerfect(number) else "Not perfect number")


if __name__ == "__main__":
    main()

"""
Explanation:
The value stored in `number` is the input that the conditions or loops work on.
The helper calculates the required result and returns it to the print statement.
The calculated answer is printed after the logic produces the final value.
"""
