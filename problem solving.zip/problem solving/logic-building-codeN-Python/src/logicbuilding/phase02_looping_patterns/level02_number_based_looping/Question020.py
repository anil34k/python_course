def main():
    # Question 20: : Print sum of first n terms of Fibonacci series.
    terms = 10
    first = 0
    second = 1
    for count in range(1, terms + 1):
        print(str(first) + " ", end="")
        next = first + second
        first = second
        second = next
    print()


if __name__ == "__main__":
    main()

"""
Explanation:
The variables `terms`, `first`, and `next` hold the values that the logic checks, counts, or transforms.
The `for` loop starts with `int count = 1`, keeps running while `count <= terms` is true, and updates using `count++`.
`System.out.println()` is used only to move to the next line after the pattern output is complete.
"""
