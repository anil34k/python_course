def main():
    # Question 24: : Find HCF (GCD) of two numbers using loops.
    first = 48
    second = 18
    while second != 0:
        remainder = first % second
        first = second
        second = remainder
    print("GCD = " + str(abs(first)))


if __name__ == "__main__":
    main()

"""
Explanation:
The variables `first`, and `remainder` hold the values that the logic checks, counts, or transforms.
The `while` or `do-while` loop keeps repeating until the changing value reaches the stopping condition.
The calculated answer is printed after the logic produces the final value.
"""
