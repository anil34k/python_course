def main():
    # Question 26: : Print all factors of a given number.
    number = 36
    for factor in range(1, number + 1):
        if number % factor == 0:
            print(factor)


if __name__ == "__main__":
    main()

"""
Explanation:
The variables `number`, and `factor` hold the values that the logic checks, counts, or transforms.
The `for` loop starts with `int factor = 1`, keeps running while `factor <= number` is true, and updates using `factor++`.
The condition `number % factor == 0` decides whether the current value matches the requirement.
The print statement shows each value as soon as that value is calculated inside the loop.
"""
