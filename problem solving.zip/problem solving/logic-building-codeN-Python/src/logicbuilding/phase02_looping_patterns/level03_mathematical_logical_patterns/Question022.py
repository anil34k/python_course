def main():
    # Question 22: : Print cubes of numbers from 1 to n.
    n = 5
    for number in range(1, n + 1):
        print(number * number * number)


if __name__ == "__main__":
    main()

"""
Explanation:
The value stored in `n` is the input that the conditions or loops work on.
The `for` loop starts with `int number = 1`, keeps running while `number <= n` is true, and updates using `number++`.
The print statement shows each value as soon as that value is calculated inside the loop.
"""
