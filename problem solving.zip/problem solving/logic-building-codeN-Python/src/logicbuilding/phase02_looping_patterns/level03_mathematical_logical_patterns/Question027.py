def main():
    # Question 27: : Find the sum of all factors of a number.
    number = 36
    sum = 0
    for factor in range(1, number + 1):
        if number % factor == 0:
            sum += factor
    print("Factor sum = " + str(sum))


if __name__ == "__main__":
    main()

"""
Explanation:
The variables `number`, `sum`, and `factor` hold the values that the logic checks, counts, or transforms.
The `for` loop starts with `int factor = 1`, keeps running while `factor <= number` is true, and updates using `factor++`.
The variable `sum` starts at 0 and collects values as the loop finds numbers that should be included.
The print statement shows each value as soon as that value is calculated inside the loop.
"""
