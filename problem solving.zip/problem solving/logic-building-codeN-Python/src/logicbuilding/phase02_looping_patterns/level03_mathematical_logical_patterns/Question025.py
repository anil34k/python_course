def main():
    # Question 25: : Find LCM of two numbers using loops.
    first = 12
    second = 18
    a = first
    b = second
    while b != 0:
        remainder = a % b
        a = b
        b = remainder
    lcm = abs(first * second) / abs(a)
    print("LCM = " + str(lcm))


if __name__ == "__main__":
    main()

"""
Explanation:
The variables `first`, `a`, `remainder`, and `lcm` hold the values that the logic checks, counts, or transforms.
The `while` or `do-while` loop keeps repeating until the changing value reaches the stopping condition.
The calculated answer is printed after the logic produces the final value.
"""
