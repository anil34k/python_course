def main():
    # Question 3: Print n Stars on Same Line.
    n = 5

    for count in range(1, n + 1):
        print("*", end="")
    print()


if __name__ == "__main__":
    main()

"""
Explanation:
The outer loop controls the rows of the pattern.
Inner loops print the required spaces, stars, numbers, or letters for each row.
After each row is complete, System.out.println() moves the output to the next line.
"""
