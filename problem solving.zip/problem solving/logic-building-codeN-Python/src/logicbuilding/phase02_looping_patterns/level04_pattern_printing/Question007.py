def main():
    # Question 7: Print Stars in Even Numbers (2, 4, 6, 8, 10).
    stars = 2
    while stars <= 10:
        for count in range(1, stars + 1):
            print("*", end="")
        print()
        stars += 2


if __name__ == "__main__":
    main()

"""
Explanation:
We use the modulo operator to check whether a value is even.
A value is even when dividing by 2 leaves remainder 0.
The code prints, counts, or adds only the values that satisfy that condition.
"""
