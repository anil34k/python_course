def main():
    # Question 18: Print alphabets in an increasing sequence per row.
    rows = 5

    for row in range(1, rows + 1):
        for column in range(1, row + 1):
            letter = ord('A') + column - 1
            print(chr(letter) + " ", end="")
        print()


if __name__ == "__main__":
    main()

"""
Explanation:
The outer loop controls the rows of the pattern.
Inner loops print the required spaces, stars, numbers, or letters for each row.
After each row is complete, System.out.println() moves the output to the next line.
"""
