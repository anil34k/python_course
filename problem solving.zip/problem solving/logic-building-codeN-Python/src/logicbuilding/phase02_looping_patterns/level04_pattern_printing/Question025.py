def main():
    # Question 25: Print the centered number pattern 5, 545, 54345, 5432345, 543212345.
    rows = 5

    for row in range(1, rows + 1):
        for space in range(1, rows - row + 1):
            print(" ", end="")

        start = rows - row + 1
        for number in range(rows, start - 1, -1):
            print(number, end="")
        for number in range(start + 1, rows + 1):
            print(number, end="")
        print()


if __name__ == "__main__":
    main()

"""
Explanation:
The outer loop controls the rows of the pattern.
Inner loops print the required spaces, stars, numbers, or letters for each row.
After each row is complete, System.out.println() moves the output to the next line.
"""
