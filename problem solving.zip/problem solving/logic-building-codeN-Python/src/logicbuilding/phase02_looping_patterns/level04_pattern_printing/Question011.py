def main():
    # Question 11: Print Numbers in an Increasing Sequence (1, 12, 123, 1234, 12345).
    rows = 5

    for row in range(1, rows + 1):
        for number in range(1, row + 1):
            print(number, end="")
        print()


if __name__ == "__main__":
    main()

"""
Explanation:
We use a counter variable to represent the current number.
The loop prints the counter while it stays inside the required range.
After every print, the counter changes so the loop can move toward the ending value.
"""
