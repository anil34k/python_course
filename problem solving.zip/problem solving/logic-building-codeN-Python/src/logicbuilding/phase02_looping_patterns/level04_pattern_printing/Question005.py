def main():
    # Question 5: Print an Increasing Triangle of Stars.
    rows = 5

    for row in range(1, rows + 1):
        for column in range(1, row + 1):
            print("*", end="")
        print()


if __name__ == "__main__":
    main()

"""
Explanation:
The outer loop controls the rows of the pattern.
Inner loops print the required spaces, stars, numbers, or letters for each row.
After each row is complete, System.out.println() moves the output to the next line.
"""
