def main():
    # Question 22: Print an expanding and shrinking star pattern.
    starCounts = [1, 2, 4, 5, 4, 3, 2, 1]

    for stars in starCounts:
        for count in range(1, stars + 1):
            print("*", end="")
        print()


if __name__ == "__main__":
    main()

"""
Explanation:
The outer loop controls the rows of the pattern.
Inner loops print the required spaces, stars, numbers, or letters for each row.
After each row is complete, System.out.println() moves the output to the next line.
"""
