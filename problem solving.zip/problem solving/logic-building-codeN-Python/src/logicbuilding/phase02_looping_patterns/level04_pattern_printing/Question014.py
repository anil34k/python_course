def main():
    # Question 14: Print a continuous digit triangle that wraps after 9.
    rows = 7
    digit = 1

    for row in range(1, rows + 1):
        for column in range(1, row + 1):
            print(str(digit) + " ", end="")
            digit += 1
            if digit == 10:
                digit = 0
        print()


if __name__ == "__main__":
    main()

"""
Explanation:
The outer loop controls the rows of the pattern.
Inner loops print the required spaces, stars, numbers, or letters for each row.
After each row is complete, System.out.println() moves the output to the next line.
"""
