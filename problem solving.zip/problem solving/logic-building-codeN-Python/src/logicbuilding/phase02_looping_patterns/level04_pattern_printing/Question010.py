def main():
    # Question 10: Print Stars and Spaces Alternating (Stars and Blank Spaces).
    rows = 5

    for row in range(1, rows + 1):
        for space in range(1, rows - row + 1):
            print(" ", end="")

        for star in range(1, row + 1):
            print("*", end="")
            if star < row:
                print(" ", end="")
        print()


if __name__ == "__main__":
    main()

"""
Explanation:
The outer loop controls how many rows are printed.
The first inner loop prints the leading blank spaces so the pattern is right-aligned.
The second inner loop prints stars, and it prints one blank space after each star except the last star in that row.
"""
