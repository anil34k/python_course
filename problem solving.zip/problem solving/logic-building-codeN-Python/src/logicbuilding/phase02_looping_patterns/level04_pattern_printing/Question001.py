def main():
    # Question 1: Print a Single Star (*).
    print("*")


if __name__ == "__main__":
    main()

"""
Explanation:
The outer loop controls the rows of the pattern.
Inner loops print the required spaces, stars, numbers, or letters for each row.
After each row is complete, System.out.println() moves the output to the next line.
"""
