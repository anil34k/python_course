def main():
    # Question 24: Print a centered diamond star pattern.
    rows = 5

    for row in range(1, rows + 1):
        for space in range(1, rows - row + 1):
            print(" ", end="")
        for star in range(1, 2 * row - 1 + 1):
            print("*", end="")
        print()

    for row in range(rows - 1, 1 - 1, -1):
        for space in range(1, rows - row + 1):
            print(" ", end="")
        for star in range(1, 2 * row - 1 + 1):
            print("*", end="")
        print()


if __name__ == "__main__":
    main()

"""
Explanation:
The outer loop controls the rows of the pattern.
Inner loops print the required spaces, stars, numbers, or letters for each row.
After each row is complete, System.out.println() moves the output to the next line.
"""
