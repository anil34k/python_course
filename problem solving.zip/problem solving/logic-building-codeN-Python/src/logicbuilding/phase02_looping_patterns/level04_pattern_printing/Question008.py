def main():
    # Question 8: Print Stars in Odd Numbers (1, 3, 5, 7, 9).
    stars = 1
    while stars <= 9:
        for count in range(1, stars + 1):
            print("*", end="")
        print()
        stars += 2


if __name__ == "__main__":
    main()

"""
Explanation:
We use the modulo operator to check whether a value is odd.
A value is odd when dividing by 2 does not leave remainder 0.
The code prints, counts, or adds only the values that satisfy that condition.
"""
