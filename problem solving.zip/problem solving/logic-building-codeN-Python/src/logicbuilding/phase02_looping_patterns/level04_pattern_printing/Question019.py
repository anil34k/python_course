def main():
    # Question 19: Print a centered continuous alphabet pyramid.
    rows = 5
    letter = ord('A')

    for row in range(1, rows + 1):
        for space in range(1, rows - row + 1):
            print(" ", end="")
        for column in range(1, 2 * row - 1 + 1):
            print(chr(letter), end="")
            letter += 1
        print()


if __name__ == "__main__":
    main()

"""
Explanation:
The outer loop controls the rows of the pattern.
Inner loops print the required spaces, stars, numbers, or letters for each row.
After each row is complete, System.out.println() moves the output to the next line.
"""
