def main():
    # Question 12: Print Repeated Numbers per Row (Same Number Repeated).
    rows = 5

    for row in range(1, rows + 1):
        for column in range(1, row + 1):
            print(row, end="")
        print()


if __name__ == "__main__":
    main()

"""
Explanation:
We set sample values at the top of the program so the question can run directly.
The loop repeats the required work and conditionals decide which values should be processed.
The final output is printed after the loop has completed the required logic.
"""
