def main():
    # Question 21: Print a centered palindrome number pyramid.
    rows = 5

    for row in range(1, rows + 1):
        for space in range(1, rows - row + 1):
            print(" ", end="")
        for number in range(1, row + 1):
            print(number, end="")
        for number in range(row - 1, 1 - 1, -1):
            print(number, end="")
        print()


if __name__ == "__main__":
    main()

"""
Explanation:
We reverse the number by taking one digit at a time from the end.
After the reverse is ready, the code compares it with the original number.
If both values are equal, the number reads the same forward and backward, so it is a palindrome.
"""
