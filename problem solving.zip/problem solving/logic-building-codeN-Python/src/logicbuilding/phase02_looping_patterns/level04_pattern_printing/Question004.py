def main():
    # Question 4: Print Square of Stars (n x n Stars).
    n = 5

    for row in range(1, n + 1):
        for column in range(1, n + 1):
            print("*", end="")
        print()


if __name__ == "__main__":
    main()

"""
Explanation:
We loop from 1 to n.
For every number, the code multiplies the number by itself.
The square value is printed before the loop moves to the next number.
"""
