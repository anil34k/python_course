def main():
    # Question 32: : Count how many numbers between 1-500 are divisible by 7 but not by 5.
    count = 0
    for number in range(1, 500 + 1):
        if number % 7 == 0 and number % 5 != 0:
            count += 1
    print("Count = " + str(count))


if __name__ == "__main__":
    main()

"""
Explanation:
The variables `count`, and `number` hold the values that the logic checks, counts, or transforms.
The `for` loop starts with `int number = 1`, keeps running while `number <= 500` is true, and updates using `number++`.
The variable `count` starts at 0 and increases only when the current item satisfies the question's condition.
The condition `number % 7 == 0 && number % 5 != 0` decides whether the current value matches the requirement.
The print statement shows each value as soon as that value is calculated inside the loop.
"""
