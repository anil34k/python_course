def sumDigits(number):
    value = abs(number)
    sum = 0
    while True:
        sum += value % 10
        value //= 10
        if not (value > 0):
            break
    return sum

def main():
    # Question 34: : Print numbers between 1-100 whose digits add up to a multiple of 3.
    for number in range(1, 100 + 1):
        if sumDigits(number) % 3 == 0:
            print(number)


if __name__ == "__main__":
    main()

"""
Explanation:
The value stored in `number` is the input that the conditions or loops work on.
The helper calculates the required result and returns it to the print statement.
The `for` loop starts with `int number = 1`, keeps running while `number <= 100` is true, and updates using `number++`.
The condition `sumDigits(number) % 3 == 0` decides whether the current value matches the requirement.
The print statement shows each value as soon as that value is calculated inside the loop.
"""
