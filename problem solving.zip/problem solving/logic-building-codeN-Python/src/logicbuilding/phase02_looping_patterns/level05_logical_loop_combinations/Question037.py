def main():
    # Question 37: Print a pattern where each row i prints i*i.
    rows = 5
    for row in range(1, rows + 1):
        for col in range(1, row + 1):
            print(row * row, end=" ")
        print()


if __name__ == "__main__":
    main()

"""
Explanation:
The value stored in `rows` is the input that the conditions or loops work on.
The outer loop controls each row of the pattern, and the inner loop controls what gets printed inside that row.
After one row is printed, `System.out.println()` moves the cursor to the next line.
`System.out.println()` is used only to move to the next line after the pattern output is complete.
"""
