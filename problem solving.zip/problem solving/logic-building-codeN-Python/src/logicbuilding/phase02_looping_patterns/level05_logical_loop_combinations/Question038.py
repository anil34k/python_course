def factorial(number):
    result = 1
    for value in range(2, number + 1):
        result *= value
    return result

def main():
    # Question 38: : Print factorial of each number from 1 to n.
    n = 6
    for number in range(1, n + 1):
        print(str(number) + "not  = " + str(factorial(number)))


if __name__ == "__main__":
    main()

"""
Explanation:
The value stored in `n` is the input that the conditions or loops work on.
The helper multiplies all numbers from 2 up to the given number to build the factorial step by step.
The `for` loop starts with `int number = 1`, keeps running while `number <= n` is true, and updates using `number++`.
The print statement shows each value as soon as that value is calculated inside the loop.
"""
