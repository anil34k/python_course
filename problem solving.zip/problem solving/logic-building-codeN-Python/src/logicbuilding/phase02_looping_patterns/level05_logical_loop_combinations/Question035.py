def main():
    # Question 35: : Find the smallest and largest digit in a given number.
    number = 58231
    value = abs(number)
    smallest = 9
    largest = 0
    while True:
        digit = value % 10
        if digit < smallest:
            smallest = digit
        if digit > largest:
            largest = digit
        value //= 10
        if not (value > 0):
            break
    print("Smallest = " + str(smallest) + ", Largest = " + str(largest))


if __name__ == "__main__":
    main()

"""
Explanation:
The value stored in `smallest` is the input that the conditions or loops work on.
The loop uses `% 10` to take the last digit and `/= 10` to remove that digit, which is the standard digit-processing pattern.
The if/else checks test the important cases in order: `digit < smallest`, `digit > largest`.
Only the branch whose condition becomes true prints its message.
"""
