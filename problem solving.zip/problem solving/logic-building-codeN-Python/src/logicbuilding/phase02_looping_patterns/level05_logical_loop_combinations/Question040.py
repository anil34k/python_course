def main():
    # Question 40: : Take 5 numbers as input. If the user enters 0, skip it using continue. At the end, print the sum of all non-zero numbers entered.
    numbers = [10, 0, 5, 7, 0]
    sum = 0
    for number in numbers:
        if number == 0:
            continue
        sum += number
    print("Sum = " + str(sum))


if __name__ == "__main__":
    main()

"""
Explanation:
The value stored in `numbers` is the input that the conditions or loops work on.
The enhanced `for` loop visits every element in the array one by one.
The variable `sum` starts at 0 and collects values as the loop finds numbers that should be included.
The print statement shows each value as soon as that value is calculated inside the loop.
"""
