def reverseNumber(number):
    value = abs(number)
    reversed = 0
    while True:
        reversed = reversed * 10 + value % 10
        value //= 10
        if not (value > 0):
            break
    return -reversed if number < 0 else reversed

def isPalindromeNumber(number):
    return abs(number) == abs(reverseNumber(number))

def main():
    # Question 33: : Print all numbers that are palindromes between 1-500.
    for number in range(1, 500 + 1):
        if isPalindromeNumber(number):
            print(number)


if __name__ == "__main__":
    main()

"""
Explanation:
The value stored in `number` is the input that the conditions or loops work on.
The helper compares the original value with its reversed form, because a palindrome reads the same both ways.
The `for` loop starts with `int number = 1`, keeps running while `number <= 500` is true, and updates using `number++`.
The condition `isPalindromeNumber(number)` decides whether the current value matches the requirement.
The print statement shows each value as soon as that value is calculated inside the loop.
"""
