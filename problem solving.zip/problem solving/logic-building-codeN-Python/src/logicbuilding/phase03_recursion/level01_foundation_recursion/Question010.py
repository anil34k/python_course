def sumDigits(number):
    value = abs(number)
    sum = 0
    while True:
        sum += value % 10
        value //= 10
        if not (value > 0):
            break
    return sum

def main():
    # Question 10: : Find sum of digits of a number recursively.
    number = 9876
    print("Sum of digits = " + str(sumDigits(number)))


if __name__ == "__main__":
    main()

"""
Explanation:
The value stored in `number` is the input that the conditions or loops work on.
The helper calculates the required result and returns it to the print statement.
The calculated answer is printed after the logic produces the final value.
"""
