def productDigits(number):
    value = abs(number)
    product = 1
    if value == 0:
        return 0
    while value > 0:
        product *= value % 10
        value //= 10
    return product

def main():
    # Question 14: : Find product of digits of a number recursively.
    number = 2345
    print("Product of digits = " + str(productDigits(number)))


if __name__ == "__main__":
    main()

"""
Explanation:
The value stored in `number` is the input that the conditions or loops work on.
The helper calculates the required result and returns it to the print statement.
The calculated answer is printed after the logic produces the final value.
"""
