def isVowel(ch):
    lower = ch.lower()
    return lower == 'a' or lower == 'e' or lower == 'i' or lower == 'o' or lower == 'u'

def countVowelsRecursive(text, index):
    if index == len(text):
        return 0
    return (1 if isVowel(text[index]) else 0) + countVowelsRecursive(text, index + 1)

def main():
    # Question 33: : Count vowels in a string recursively.
    text = "recursion"
    print("Vowels = " + str(countVowelsRecursive(text, 0)))


if __name__ == "__main__":
    main()

"""
Explanation:
The value stored in `text` is the input that the conditions or loops work on.
The recursive return `(isVowel(text.charAt(index)) ? 1 : 0) + countVowelsRecursive(text, index + 1)` solves a smaller part first, then combines it with the current value.
The recursive call `countVowelsRecursive(text, index + 1)` moves the work toward the base case by changing the argument each time.
The calculated answer is printed after the logic produces the final value.
"""
