def replaceCharRecursive(text, index, oldChar, newChar):
    if index == len(text):
        return ""
    ch = newChar if text[index] == oldChar else text[index]
    return ch + replaceCharRecursive(text, index + 1, oldChar, newChar)

def main():
    # Question 35: : Replace all occurrences of a character (say 'a' -> 'x') recursively.
    text = "banana"
    print(replaceCharRecursive(text, 0, 'a', 'x'))


if __name__ == "__main__":
    main()

"""
Explanation:
The value stored in `text` is the input that the conditions or loops work on.
The recursive return `ch + replaceCharRecursive(text, index + 1, oldChar, newChar)` solves a smaller part first, then combines it with the current value.
The recursive call `replaceCharRecursive(text, index + 1, oldChar, newChar)` moves the work toward the base case by changing the argument each time.
The calculated answer is printed after the logic produces the final value.
"""
