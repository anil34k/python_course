def printCharactersRecursive(text, index):
    if index == len(text):
        return
    print(text[index])
    printCharactersRecursive(text, index + 1)

def main():
    # Question 37: : Print all characters of a string one by one recursively.
    printCharactersRecursive("logic", 0)


if __name__ == "__main__":
    main()

"""
Explanation:
The values `"logic", 0` passed to `printCharactersRecursive` set the starting point and stopping limit for the recursive logic.
The recursive call `printCharactersRecursive(text, index + 1)` moves the work toward the base case by changing the argument each time.
One value is printed before the next recursive call, so the output is built step by step.
"""
