def removeSpacesRecursive(text, index):
    if index == len(text):
        return ""
    ch = text[index]
    return ("" if ch == ' ' else ch) + removeSpacesRecursive(text, index + 1)

def main():
    # Question 34: : Remove all spaces from a string recursively.
    text = "lo g ic"
    print(removeSpacesRecursive(text, 0))


if __name__ == "__main__":
    main()

"""
Explanation:
The value stored in `text` is the input that the conditions or loops work on.
The recursive return `(ch == ' ' ? "" : ch) + removeSpacesRecursive(text, index + 1)` solves a smaller part first, then combines it with the current value.
The recursive call `removeSpacesRecursive(text, index + 1)` moves the work toward the base case by changing the argument each time.
The calculated answer is printed after the logic produces the final value.
"""
