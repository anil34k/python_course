def reverseRecursive(text):
    if text == "":
        return ""
    return reverseRecursive(text.substring(1)) + text[0]

def main():
    # Question 31: : Reverse a string using recursion.
    text = "logic"
    print(reverseRecursive(text))


if __name__ == "__main__":
    main()

"""
Explanation:
The value stored in `text` is the input that the conditions or loops work on.
The recursive return `reverseRecursive(text.substring(1)) + text.charAt(0)` solves a smaller part first, then combines it with the current value.
The calculated answer is printed after the logic produces the final value.
"""
