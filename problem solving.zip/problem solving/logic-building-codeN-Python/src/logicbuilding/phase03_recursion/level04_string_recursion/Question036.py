def removeCharRecursive(text, index, target):
    if index == len(text):
        return ""
    ch = text[index]
    return ("" if ch == target else ch) + removeCharRecursive(text, index + 1, target)

def main():
    # Question 36: : Remove all occurrences of a character from a string recursively.
    text = "banana"
    print(removeCharRecursive(text, 0, 'a'))


if __name__ == "__main__":
    main()

"""
Explanation:
The value stored in `text` is the input that the conditions or loops work on.
The recursive return `(ch == target ? "" : ch) + removeCharRecursive(text, index + 1, target)` solves a smaller part first, then combines it with the current value.
The recursive call `removeCharRecursive(text, index + 1, target)` moves the work toward the base case by changing the argument each time.
The calculated answer is printed after the logic produces the final value.
"""
