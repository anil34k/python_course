def toUpperRecursive(text, index):
    if index == len(text):
        return ""
    return text[index].upper() + toUpperRecursive(text, index + 1)

def main():
    # Question 39: : Convert a string to uppercase recursively.
    print(str(toUpperRecursive("logic", 0)))


if __name__ == "__main__":
    main()

"""
Explanation:
The values `toUpperRecursive("logic", 0)` passed to `println` set the starting point and stopping limit for the recursive logic.
The recursive return `Character.toUpperCase(text.charAt(index)) + toUpperRecursive(text, index + 1)` solves a smaller part first, then combines it with the current value.
The recursive call `toUpperRecursive(text, index + 1)` moves the work toward the base case by changing the argument each time.
The calculated answer is printed after the logic produces the final value.
"""
