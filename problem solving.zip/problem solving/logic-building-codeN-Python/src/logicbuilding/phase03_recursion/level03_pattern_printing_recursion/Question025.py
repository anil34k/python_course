def printNumberPattern(row, n):
    if row > n:
        return
    for i in range(1, row + 1):
        print(str(i) + " ", end="")
    print()
    printNumberPattern(row + 1, n)

def main():
    # Question 25: : Print pattern of numbers recursively (1 to n each row).
    printNumberPattern(1, 5)


if __name__ == "__main__":
    main()

"""
Explanation:
The values `1, 5` passed to `printNumberPattern` set the starting point and stopping limit for the recursive logic.
Inside `printNumberPattern`, the condition `row > n` is the base case; it stops the repeated recursive calls.
The recursive call `printNumberPattern(row + 1, n)` moves the work toward the base case by changing the argument each time.
Inside each recursive step, the loop starts with `int i = 1`, runs while `i <= row` is true, and updates with `i++` to print that row.
"""
