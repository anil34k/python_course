def printStars(n):
    if n == 0:
        return
    print("*", end="")
    printStars(n - 1)

def printTriangleBottomUp(row):
    if row == 0:
        return
    printStars(row)
    print()
    printTriangleBottomUp(row - 1)

def main():
    # Question 24: : Print a triangle of stars recursively (bottom-up).
    printTriangleBottomUp(5)


if __name__ == "__main__":
    main()

"""
Explanation:
The values `5` passed to `printTriangleBottomUp` set the starting point and stopping limit for the recursive logic.
Inside `printTriangleBottomUp`, the condition `row == 0` is the base case; it stops the repeated recursive calls.
The recursive call `printTriangleBottomUp(row - 1)` moves the work toward the base case by changing the argument each time.
One value is printed before the next recursive call, so the output is built step by step.
"""
