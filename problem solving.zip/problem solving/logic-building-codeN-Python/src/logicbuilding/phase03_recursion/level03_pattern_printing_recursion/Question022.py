def printStars(n):
    if n == 0:
        return
    print("*", end="")
    printStars(n - 1)

def printStarSquare(rows, columns):
    if rows == 0:
        return
    printStars(columns)
    print()
    printStarSquare(rows - 1, columns)

def main():
    # Question 22: : Print a square of stars recursively (n x n).
    printStarSquare(5, 5)


if __name__ == "__main__":
    main()

"""
Explanation:
The values `5, 5` passed to `printStarSquare` set the starting point and stopping limit for the recursive logic.
Inside `printStarSquare`, the condition `rows == 0` is the base case; it stops the repeated recursive calls.
The recursive call `printStarSquare(rows - 1, columns)` moves the work toward the base case by changing the argument each time.
One value is printed before the next recursive call, so the output is built step by step.
"""
