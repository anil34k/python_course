def printCharacterPattern(row, n):
    if row > n:
        return
    for ch in range(ord('A'), ord('A') + row):
        ch = chr(ch)
        print(ch, end="")
    print()
    printCharacterPattern(row + 1, n)

def main():
    # Question 30: : Print pattern of characters (A, AB, ABC, ...) recursively.
    printCharacterPattern(1, 5)


if __name__ == "__main__":
    main()

"""
Explanation:
The values `1, 5` passed to `printCharacterPattern` set the starting point and stopping limit for the recursive logic.
Inside `printCharacterPattern`, the condition `row > n` is the base case; it stops the repeated recursive calls.
The recursive call `printCharacterPattern(row + 1, n)` moves the work toward the base case by changing the argument each time.
Inside each recursive step, the loop starts with `char ch = 'A'`, runs while `ch < 'A' + row` is true, and updates with `ch++` to print that row.
"""
