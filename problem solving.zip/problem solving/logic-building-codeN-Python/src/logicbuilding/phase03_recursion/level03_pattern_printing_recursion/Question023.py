def printStars(n):
    if n == 0:
        return
    print("*", end="")
    printStars(n - 1)

def printTriangleTopDown(row, n):
    if row > n:
        return
    printStars(row)
    print()
    printTriangleTopDown(row + 1, n)

def main():
    # Question 23: : Print a triangle of stars recursively (top-down).
    printTriangleTopDown(1, 5)


if __name__ == "__main__":
    main()

"""
Explanation:
The values `1, 5` passed to `printTriangleTopDown` set the starting point and stopping limit for the recursive logic.
Inside `printTriangleTopDown`, the condition `row > n` is the base case; it stops the repeated recursive calls.
The recursive call `printTriangleTopDown(row + 1, n)` moves the work toward the base case by changing the argument each time.
One value is printed before the next recursive call, so the output is built step by step.
"""
